dgp<-function(tt,beta1,beta2,a,gamma_real,L,J,K,pz,z,e){
  # tt=100
  # beta1=c(1,0,1,1,rep(0,times=6))
  # beta2=c(-1,-2,1,-1,rep(0,times=6))
  # a=1
  # gamma_real=c(0.1,0.5,0.6,rep(0,times=3))
  # L=3
  # J=12
  # K=3
  # pz=5
  # z='independent'
  # e="gaussian"
  LK=L*K
  JK=J*K
  beta=c(beta1,a*beta2)
  ###勒让德多项式###
  degree <- (L-1)
  jmax <- 12
  Q_V<-matrix(lb(degree = degree,jmax = jmax)/jmax,ncol = L,nrow = jmax)
  ###q正态分布####
  q<-rnorm((tt+100),mean=0.1,sd=0.61)
  
  ####示性函数#### 
  pos.part <- function(q, r){ifelse(q>r,1,0)}
  neg.part <- function(q, r){ifelse(q<=r,1,0)}
  
  
  ###生成高频协变量####
  rho=0.2
  ##rho=0.7
  xe=matrix(0,20000,K)
  for(i in 1:K){
    xc=rep(0,times=20000)
    xc[1]=rnorm(1,mean=0,sd=1/(1-rho^2))
    for(j in 2:20000){
      eps=rnorm(1)
      xc[j]=rho*xc[(j-1)]+eps
    }
    xe[,i]=xc
  }
  xe=xe[201:20000,]
  
  xr=matrix(0,(tt+100),JK)
  for(i in 1:K){
    iJ=i*J
    for(j in 1:(tt+100)){
      jJ=j*J
      xr[j,(iJ-11):iJ]=xe[(jJ-11):jJ,i]
    }
  }
  ####生成低频协变量####
  slo=rep(1,times=(tt+100))
 
  dim(xr)<-c((tt+100),J,K)
  x1=matrix(nrow=(tt+100),ncol=0)
  for(i in 1:K){
    xk1=xr[,,i]%*%Q_V
    x1=cbind(x1,xk1)
  }
  x1=as.matrix(x1)
  
  ####生成高维门槛变量####
  if(z=="independent"){
    zt<-matrix(rnorm((tt+100)* pz),(tt+100), pz)
  }
  
  if(z=="dependent"){
    zt2<-matrix(0,nrow=(tt+100),ncol=2)
    for(i in 1:2){
      for(j in 1:(tt+100)){
        zt2[j,i]=mean(xe[(3*j-2):(3*j),i])
      }
    }
    zt1<-matrix(rnorm((tt+100)* (pz-2)),(tt+100), (pz-2))
    zt=cbind(zt1,zt2)
  }
  zt_con=rep(1,times=(tt+100))
  rt = cbind(zt_con,zt)%*%gamma_real
  rt=as.numeric(rt)# threshold
  
  ####划分变量####
  slo1<-slo#*pos.part(q,rt)
  slo2<-slo*neg.part(q,rt)
  
  xk1=x1#*pos.part(q,rt)
  xk2=x1*neg.part(q,rt)
  
  X=cbind(slo1,xk1,slo2,xk2)
  
  ####生成garch误差####
  eps=rep(0,times=(tt+101))
  h=rep(0,times=(tt+101))
  h[1]=abs(rnorm(1))
  if(e=="gaussian"){
    ut=rnorm(1,sd=1)
  }
  if(e=="non-gaussian"){
    ut=rt(1,df=5)
  }
  eps[1]=sqrt(h[1])*ut
  
  for(i in 1:(tt+100)){
    if(e=="gaussian"){
      ut=rnorm(1,sd=1)
    }
    if(e=="non-gaussian"){
      ut=rt(1,df=5)
    }
    h[(i+1)]=0.0005+0.9*h[(i)]+0.05*(eps[(i)])^2
    eps[(i+1)]=h[i+1]^0.5*ut
    
  }
  ####生成被解释变量###
  y=X%*%beta+eps[2:(tt+101)]
  y1=X%*%beta
  
  
  ###划分训练集和测试集####
  y_train=y[1:(tt)]
  y_test=y[(tt+1):(tt+100)]
  y1_train=y1[1:(tt)]
  y1_test=y1[(tt+1):(tt+100)]
  x_train=x1[1:(tt),]
  x_test=x1[(tt+1):(tt+100),]
  zt_train=zt[1:(tt),]
  zt_test=zt[(tt+1):(tt+100),]
  slo_train=slo[1:(tt)]
  slo_test=slo[(tt+1):(tt+100)]
  q_train=q[1:(tt)]
  q_test=q[(tt+1):(tt+100)]
  
  
  
  return(list(beta=beta,gamma_real=gamma_real,y_train=y_train,y_test=y_test,y1_train=y1_train,y1_test=y1_test,x_train=x_train,x_test=x_test,zt_train=zt_train,zt_test=zt_test,slo_train=slo_train,slo_test=slo_test,q_train=q_train,q_test=q_test,L=L,K=K,J=J,LK=LK,JK=JK,pz=pz,tt=tt,eps=eps))
}