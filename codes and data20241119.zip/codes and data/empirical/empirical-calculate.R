rm(list=ls())
set.seed(16)

source('~/Desktop/HDMIDASCDT-46/codes and data/empirical/DGP.R')
source('~/Desktop/HDMIDASCDT-46/codes and data/empirical/empirical-function.R')

dgp1=DGP(12,0,3)
J=12
L=3
K=43
pz=10
y<-dgp1$data_y_train[13:172,2]
x<-dgp1$data_x_trainfinal
zt<-dgp1$data_zt_train[13:172,2:11]
q<-dgp1$data_y_train[12:171,2]
y=as.matrix(y)
x=as.matrix(x)
zt=as.matrix(zt)
q=as.matrix(q)

my_function<-function(i){
  
  tt=100#(99+i)
  y_train=y[(i+0):(i+99)]
  x_train=x[(i+0):(i+99),]
  q_train=q[(i+0):(i+99)]
  zt_train=zt[(i+0):(i+99),]
  y_train=as.matrix(y_train)
  x_train=as.matrix(x_train)
  q_train=as.matrix(q_train)
  zt_train=as.matrix(zt_train)
  y_test=y[i+100]
  x_test=x[(i+100),]
  q_test=q[i+100]
  zt_test=zt[(i+100),]
  y_test=as.matrix(y_test)
  x_test=as.matrix(x_test)
  x_test=t(x_test)
  q_test=as.matrix(q_test)
  zt_test=as.matrix(zt_test)
  zt_test=t(zt_test)
  
  rt_choose1<-rt_choose(y=y_train,x=x_train,q=q_train,zt=zt_train,J=J,L=L,K=K,pz=pz,tt=tt)
  
  ###选择解释变量###
  x_choose1<-x_choose(q=q_train,zt=zt_train,y=y_train,x=x_train,tt=tt,L=L,J=J,K=K,corr=rt_choose1$corr)
  
  ###预测###
  pre1<-pre(y=y_test,x=x_test,q=q_test,zt=zt_test,gahat=x_choose1$gahat,beita_hat=x_choose1$beita_hat,L=L,J=J,K=K,corr=rt_choose1$corr)
  
  ##无门槛###
  x_choose_noth1<-x_choose_noth(y=y_train,x=x_train,tt=tt,L=L,J=J,K=K)
  
  ###预测###
  pre_noth1<-pre_noth(y=y_test,x=x_test,beita_hat=x_choose_noth1$beita_hat,L=L,J=J,K=K)
  
  ###AR1###
  ar1_result<-ar1(y_train=y_train,y_test=y_test,tt=tt)
  
  return(list(et1=pre1$et,rmse1=pre1$rmse,yhat1=pre1$yhat,coaa=x_choose1$coaa,cobb=x_choose1$cobb,cocc=x_choose1$cocc,coll1=x_choose1$coll1,coll2=x_choose1$coll2,indicator1=pre1$indicator1,indicator2=pre1$indicator2,et2=pre_noth1$et_noth,rmse2=pre_noth1$rmse_noth,yhat2=pre_noth1$yhat,coll3=x_choose_noth1$coll,et3=ar1_result$et,rmse3=ar1_result$rmse,yhat3=ar1_result$yhat,gi=x_choose1$gi))
}



library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <- 60
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

cl <- makeSOCKcluster(xc)#设置参与并行核数
registerDoSNOW(cl) 
time1 <- Sys.time()

result1<-foreach(i = 1:Btimes, .inorder = TRUE,.packages = c('msgps','midasml',"BayesianTools"),.combine = rbind,.options.snow=opts) %dopar% {
  my_function1<-my_function(i)
  return(c(my_function1$et1,my_function1$rmse1,my_function1$yhat1,my_function1$et2,my_function1$rmse2,my_function1$yhat2,my_function1$et3,my_function1$rmse3,my_function1$yhat3,my_function1$coaa,my_function1$cobb,my_function1$cocc,my_function1$coll1,my_function1$coll2,my_function1$coll3,my_function1$indicator1,my_function1$indicator2))
}

Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算



et1=result1[,1]
et2=result1[,4]
et3=result1[,7]
resi1=result1[,2]
resi2=result1[,5]
resi3=result1[,8]
yhat1=result1[,3]
yhat2=result1[,6]
yhat3=result1[,9]

mse11=(sum(resi1[1:60]))/60
mse21=(sum(resi2[1:60]))/60
mse31=(sum(resi3[1:60]))/60
rmse11=sqrt(sum(resi1[1:60])/60)
rmse21=sqrt(sum(resi2[1:60])/60)
rmse31=sqrt(sum(resi3[1:60])/60)
mae11=(sum(abs(et1[1:60])))/60
mae21=(sum(abs(et2[1:60])))/60
mae31=(sum(abs(et3[1:60])))/60
e11=abs(et1[1:60])
e21=abs(et2[1:60])
e31=abs(et3[1:60])
mse12=(sum(resi1[1:48]))/48
mse22=(sum(resi2[1:48]))/48
mse32=(sum(resi3[1:48]))/48
rmse12=sqrt(sum(resi1[1:48])/48)
rmse22=sqrt(sum(resi2[1:48])/48)
rmse32=sqrt(sum(resi3[1:48])/48)
mae12=(sum(abs(et1[1:48])))/48
mae22=(sum(abs(et2[1:48])))/48
mae32=(sum(abs(et3[1:48])))/48
e12=abs(et1[1:48])
e22=abs(et2[1:48])
e32=abs(et3[1:48])
mse13=(sum(resi1[49:60]))/12
mse23=(sum(resi2[49:60]))/12
mse33=(sum(resi3[49:60]))/12
rmse13=sqrt(sum(resi1[49:60])/12)
rmse23=sqrt(sum(resi2[49:60])/12)
rmse33=sqrt(sum(resi3[49:60])/12)
mae13=(sum(abs(et1[49:60])))/12
mae23=(sum(abs(et2[49:60])))/12
mae33=(sum(abs(et3[49:60])))/12
e13=abs(et1[49:60])
e23=abs(et2[49:60])
e33=abs(et3[49:60])
dm121=dm.test(e11,e21,h=1,alternative="less",power=1)
dm131=dm.test(e11,e31,h=1,alternative="less",power=1)
dm231=dm.test(e21,e31,h=1,alternative="less",power=1)
dm122=dm.test(e12,e22,h=1,alternative="less",power=1)
dm132=dm.test(e12,e32,h=1,alternative="less",power=1)
dm232=dm.test(e22,e32,h=1,alternative="less",power=1)
dm123=dm.test(e13,e23,h=1,alternative="less",power=1)
dm133=dm.test(e13,e33,h=1,alternative="less",power=1)
dm233=dm.test(e23,e33,h=1,alternative="less",power=1)



save.image('C:/Users/Administrator.DESKTOP-CGN84Q5/Desktop/HDMIDASCDT-31/codes and data/empirical/EoQ3.Rdata')

####累积误差图###
###全样本###
t=c(1:60)
rmsetel11=sqrt(cumsum(resi1[1:60]))
rmsetel21=sqrt(cumsum(resi2[1:60]))
rmsetel31=sqrt(cumsum(resi3[1:60]))
par(pin = c(6,1.25))
plot(x=t, y=rmsetel11,type="o",xlab="Month",ylab="CUMSFE ",xaxt = "n",col="red",ylim=c(0,70))
title("(a): Full sample")
axis(1,at=c(1,9,17,25,33,41,49,57),labels=c("2008","2010","2012","2014","2016","2018","2020","2022"))
lines(x=t, y=rmsetel21,type="o",col="green")
lines(x=t, y=rmsetel31,type="o",col="blue")

####平稳####
t=c(1:48)
rmsetel11=sqrt(cumsum(resi1[1:48]))
rmsetel21=sqrt(cumsum(resi2[1:48]))
rmsetel31=sqrt(cumsum(resi3[1:48]))
par(pin = c(6,1.25))
plot(x=t, y=rmsetel11,type="o",xlab="Month",ylab="CUMSFE ",xaxt = "n",col="red",ylim=c(0,25))
title("(b): Period of stable economic excluding the COVID pandemic")
axis(1,at=c(1,9,17,25,33,41,49),labels=c("2008","2010","2012","2014","2016","2018","2020"))
lines(x=t, y=rmsetel21,type="o",col="green")
lines(x=t, y=rmsetel31,type="o",col="blue")

####波动####
t=c(1:12)
rmsetel11=sqrt(cumsum(resi1[49:60]))
rmsetel21=sqrt(cumsum(resi2[49:60]))
rmsetel31=sqrt(cumsum(resi3[49:60]))
par(pin = c(6,1.25))
plot(x=t, y=rmsetel11,type="o",xlim = c(1, 13),xlab="Month",ylab="CUMSFE ",xaxt = "n",col="red",ylim=c(0,70))
title("(c): Period during and after the COVID pandemic")
axis(1,at=c(1,5,9,13),labels=c("2020","2021","2022","2023"))
lines(x=t, y=rmsetel21,type="o",col="green")
lines(x=t, y=rmsetel31,type="o",col="blue")


####预测图###
###全样本###
t=c(1:60)
par(pin = c(6,1.25))
plot(x=t, y=yhat1,type="o",xlab="Month",ylab="Yhat ",xaxt = "n",col="red",ylim=c(-40,40))
title("(a): Full sample")
axis(1,at=c(1,9,17,25,33,41,49,57),labels=c("2008","2010","2012","2014","2016","2018","2020","2022"))
lines(x=t, y=yhat2,type="o",col="green")
lines(x=t, y=yhat3,type="o",col="blue")
lines(x=t, y=y[101:160],type="o",col="black")

####平稳####
t=c(1:48)
par(pin = c(6,1.25))
plot(x=t, y=yhat1[1:48],type="o",xlab="Month",ylab="Yhat ",xaxt = "n",col="red",ylim=c(-10,10))
title("(b): Period of stable economic excluding the COVID pandemic")
axis(1,at=c(1,9,17,25,33,41,49),labels=c("2008","2010","2012","2014","2016","2018","2020"))
lines(x=t, y=yhat2[1:48],type="o",col="green")
lines(x=t, y=yhat3[1:48],type="o",col="blue")
lines(x=t, y=y[101:148],type="o",col="black")

####波动####
t=c(1:12)
par(pin = c(6,1.25))
plot(x=t, y=yhat1[49:60],type="o",xlim = c(1, 13),xlab="Month",ylab="Yhat ",xaxt = "n",col="red",ylim=c(-40,40))
title("(c): Period during and after the COVID pandemic")
axis(1,at=c(1,5,9,13),labels=c("2020","2021","2022","2023"))
lines(x=t, y=yhat2[49:60],type="o",col="green")
lines(x=t, y=yhat3[49:60],type="o",col="blue")
lines(x=t, y=y[149:160],type="o",col="black")
