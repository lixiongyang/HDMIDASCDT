This file describes the data files and R programs necessary to replicates tables and simulations for the paper “{High Dimensional Mixed Data Sampling  Models with a Covariate-Dependent Threshold”. The contents of the .zip file are detailed below. 

In the “simulation” folder, there are the files that permit to replicate Table 1 and Table 2 of the paper, i.e., the model estimation and prediction results in the simulation part.

The R files "feqen", “function_bic.R” and “dgp.R” are R functions used to estimate the suggested high dimensional mixed data sampling model with covariate-dependent thresholds and evaluate the accuracy of variable selection of the model.
Running the file “choosegamma.R”allows the replication of Table 1 of the paper . 
Running the file “simulation_bic.R” allows the replication of Table 2 of the paper . 

In the “empirical” folder, there are the files that permit to replicate Figure 1,2,3,4 and Table 3 of the paper, i.e., the empirical results in the application part. 
The "empirical-function.R","DGP.R" is the functions used in the application part.
Running the file “empirical-calculate.R”, allows the replication of Table 3 and Figure 1,2,3,4 of the paper . 