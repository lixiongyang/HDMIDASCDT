library("glmnet")
library("midasml")
library('BayesianTools')
library("pracma")
library("forecast")
library("readxl")
library("softImpute")
library("msgps")


bic.sglfit <- function(x, y,gindex,standardize,intercept,lambda.factor){
  tp <- dim(x)
  t <- tp[1]
  p <- tp[2]
  
  allgamma=seq(0,1,by=0.1)
  grid_gamma=length(allgamma)
  bic_gamma=rep(NA,times=grid_gamma)
  beita_gamma=matrix(NA,nrow=p,ncol=grid_gamma)
  b0_gamma=rep(NA,times=grid_gamma)
  lambda_gamma=rep(NA,times=grid_gamma)
  
  for(i in 1:grid_gamma){
    gamma=allgamma[i]
    sglfit.object <- sglfit(x=x,y=y,gamma=gamma,gindex=gindex,standardize=standardize,intercept=intercept,lambda.factor=lambda.factor)
    lambda <- sglfit.object$lambda
    
    nlam <- length(lambda)
    cvm <- rep(NA, times = nlam)
    yhats <- predict(sglfit.object, newx = x)
    df <- sglfit.object$df
    sigsqhat <- sum((y-mean(y))^2)/t
    mse <- colSums((replicate(nlam, as.numeric(y))-yhats)^2)/t
    cvm <-mse/sigsqhat + log(t)/t*df 
    
    lamin <- lambda[which(cvm==min(cvm))]
    if (length(lamin)>1)
      lamin <- min(lamin)
    
    min.crit <- min(cvm)
    idx<- which(lamin==lambda)
    
    bic_gamma[i]=min.crit
    beita_gamma[,i]=sglfit.object$beta[,idx]
    b0_gamma[i]=sglfit.object$b0[idx]
    lambda_gamma[i]=lamin
  }
  
  gi = which(bic_gamma==min(bic_gamma),arr.ind=F)
  if (length(gi)>1)
    gi<- max(gi)
  gamma=allgamma[gi]
  beita_hat=beita_gamma[,gi]
  b0_hat=b0_gamma[gi]
  lamin=lambda_gamma[gi]
  
  return(list(gi=gi,beita_hat=beita_hat,b0_hat=b0_hat,lamin=lamin))
}

###选择影响门槛值的协变量###
rt_choose<-function(y,x,q,zt,J,L,K,pz,tt){
  
  LK=L*K
  JK=J*K
  y=as.numeric(y)
  
  x20=matrix(nrow=0,ncol=((56+LK)*(pz)))
  for(i in 1:tt){
    xizj=kronecker(x[i,],zt[i,])
    x20=rbind(x20,xizj)
  }
  x10=matrix(nrow=0,ncol=(56+LK))
  for(i in 1:tt){
    xiq=x[i,]*q[i]
    x10=rbind(x10,xiq)
  }
  x20=as.matrix(x20)
  x10=as.matrix(x10)
  B=cbind(zt,x,q,x10,x20)
  B=as.matrix(B)
  dim=ncol(B)
  
  alasso_fit=msgps(B,y,penalty="alasso",alpha=0,gamma=1,DFtype="MODIFIED",intercept=TRUE,stand.coef=TRUE)
  gamma_est=alasso_fit$dfbic_result$coef[2:(pz+1)]
  
  
  corr=matrix(nrow=1,ncol=0)
  for(i in 1:pz){
    if(gamma_est[i]!=0){
      corr=cbind(corr,i)
    }
    else{
      corr=corr
    }
  }
  corr=as.numeric(corr)
  
  return(list(corr=corr))
}

##选择解释变量###
x_choose<-function(q,zt,y,x,tt,L,J,K,corr){
  # q=q_train
  # zt=zt_train
  # y=y_train
  # x=x_train
  # tt=tt
  # L=L
  # J=J
  # K=K
  # corr=rt_choose1$corr
  LK=L*K
  JK=J*K
  pos.part <- function(q, r){ifelse(q>r,1,0)}
  neg.part <- function(q, r){ifelse(q<=r,1,0)}
  
  slo=rep(1,times=tt)
  q=as.numeric(q)
  
  sse_ga<-function(ga){
    
    if(length(corr)==0){
      gamma_sse=rep(ga,tt)
    }else{
      zt_tel=matrix(nrow=tt,ncol=0)
      for(i in 1:length(corr)){
        num=corr[i]
        zt_tel=cbind(zt_tel,zt[,num])
      }
      zt1=rep(1,times=tt)
      zt_tel=cbind(zt1,zt_tel)
      gamma_sse<-zt_tel%*%ga
    }
    gamma_sse=as.numeric(gamma_sse)
    if (sum(pos.part(q,gamma_sse))/tt>=0.15&&sum(pos.part(q,gamma_sse))/tt<=0.85){
      slo1_sse<-slo*pos.part(q,gamma_sse)
      slo2_sse<-slo*neg.part(q,gamma_sse)
      
      x1_sse=x*pos.part(q,gamma_sse)
      x2_sse=x*neg.part(q,gamma_sse)
      
      
      X_sse<-cbind(slo1_sse,x1_sse,slo2_sse,x2_sse)
      
      gindex =sort(c(1,rep(2:15,times=4),rep(16:(K+15),times=L),(K+16),rep((K+17):(K+30),times=4),rep((K+31):(2*K+30),times=L)))
      biclasso<-bic.sglfit(x=X_sse,y=y,gindex = gindex,standardize=TRUE,intercept=FALSE,lambda.factor=0.01)
      beita_hat=biclasso$beita
      
      sse_es <- sum((y - as.numeric(X_sse%*%beita_hat))^2)
      return(sse_es)}
    else{
      return(Inf)}
    
  }
  
  r1 <- quantile(q, probs = 0.15)
  r2 <- quantile(q, probs = 0.85)
  
  ####mcmc####
  ms=300
  bur=300
  miq = mean(q)
  pdffun_new <- function(ga) {
    pn = -sse_ga(ga)
    return(pn)
  }
  
  jj = matrix(1,nrow =tt,ncol = 1)
  jj = cbind(jj,zt)
  nhe1 = qr.resid(qr(jj),q)
  lc = max(abs(nhe1)) + 1
  left_c = (nhe1 - lc)
  right_c = (nhe1 + lc)
  left_c = min(left_c)
  right_c= max(right_c)
  # c=max(abs(r1),abs(r2))
  # priors<-createUniformPrior(lower=c(r1,-c),upper=c(r2,c))
  priors<-createUniformPrior(lower=c(r1,rep(left_c,times=length(corr))),upper=c(r2,rep(right_c,times=length(corr))))
  bayesianSetup<-createBayesianSetup(pdffun_new,prior=priors)
  sett_trainings=list(iterations=(ms+bur),burnin=bur)
  gapost <- runMCMC(bayesianSetup=bayesianSetup,sampler="DREAMzs",settings=sett_trainings)
  gelmanDiagnostics(gapost,plot = T)
  gahat<-MAP(gapost)$parametersMAP
  
  if(length(corr)==0){
    rt_es=rep(gahat,tt)
  }else{
    zt_fin=matrix(nrow=tt,ncol=0)
    for(i in 1:length(corr)){
      num=corr[i]
      zt_fin=cbind(zt_fin,zt[,num])
    }
    zt1=rep(1,times=tt)
    zt_fin=cbind(zt1,zt_fin)
    rt_es =zt_fin%*%gahat
  }
  rt_es=as.numeric(rt_es)
  
  slo1_fin<-slo*pos.part(q,rt_es)
  slo2_fin<-slo*neg.part(q,rt_es)
  
  
  x1_fin=x*pos.part(q,rt_es)
  x2_fin=x*neg.part(q,rt_es)
  
  X_fin<-cbind(slo1_fin,x1_fin,slo2_fin,x2_fin)
  
  gindex =sort(c(1,rep(2:15,times=4),rep(16:(K+15),times=L),(K+16),rep((K+17):(K+30),times=4),rep((K+31):(2*K+30),times=L)))
  bicsglasso<-bic.sglfit(x=X_fin,y=y,gindex = gindex,standardize=TRUE,intercept=FALSE,lambda.factor=0.01)
  beita_hat=bicsglasso$beita
  
  beita1_hat=beita_hat[1:(57+LK)]
  beita2_hat=beita_hat[(58+LK):(2*LK+114)]
  delta=beita1_hat-beita2_hat
  coaa=sum(delta!=0)
  
  coll1=matrix(nrow=1,ncol=0)
  for(i in 1:(LK+57)){
    if(beita1_hat[i]!=0){
      coll1=cbind(coll1,i)
    }
    else{
      coll1=coll1
    }
  }
  cobb=length(coll1)
  coll1=c(coll1,rep(0,times=(20-cobb)))
  coll1=as.numeric(coll1)
  
  coll2=matrix(nrow=1,ncol=0)
  for(i in 1:(LK+57)){
    if(beita2_hat[i]!=0){
      coll2=cbind(coll2,i)
    }
    else{
      coll2=coll2
    }
  }
  cocc=length(coll2)
  coll2=c(coll2,rep(0,times=(20-cocc)))
  coll2=as.numeric(coll2)
  
  
  
  
  return(list(beita_hat=beita_hat,gahat=gahat,delta=delta,coll1=coll1,coll2=coll2,coaa=coaa,cobb=cobb,cocc=cocc))
}

###预测###
pre<-function(y,x,q,zt,gahat,beita_hat,L,J,K,corr){
  # y=y_test
  # x=x_test
  # q=q_test
  # zt=zt_test
  # gahat=x_choose1$gahat
  # beita_hat=x_choose1$beita
  # L=L
  # J=J
  # K=K
  # corr=rt_choose1$corr
  LK=L*K
  JK=J*K
  pos.part <- function(q, r){ifelse(q>r,1,0)}
  neg.part <- function(q, r){ifelse(q<=r,1,0)}
  q=as.numeric(q)
  slo=1
  
  if(length(corr)==0){
    gamma=gahat
  }else{
    zt=t(zt)
    zt_tel=matrix(nrow=1,ncol=0)
    for(i in 1:length(corr)){
      num=corr[i]
      zt_tel=cbind(zt_tel,zt[num])
    }
    zt1=1
    zt_tel=cbind(zt1,zt_tel)
    gamma <-zt_tel%*%gahat
  }
  gamma=as.numeric(gamma)
  
  slo1<-slo*pos.part(q,gamma)
  slo2<-slo*neg.part(q,gamma)
  
  x1=x*pos.part(q,gamma)
  x2=x*neg.part(q,gamma)
  
  X<-cbind(slo1,x1,slo2,x2)
  et=sum((y-as.numeric(X%*%beita_hat)))
  rmse=sum((y-as.numeric(X%*%beita_hat))^2)
  yhat=as.numeric(X%*%beita_hat)
  
  indicator1=pos.part(q,gamma)
  indicator2=neg.part(q,gamma)
  
  return(list(rmse=rmse,et=et,yhat=yhat,indicator1=indicator1,indicator2=indicator2))
}


#####无门槛#####
x_choose_noth<-function(y,x,tt,L,J,K){
  # y=y_train
  # x=x_train
  # tt=tt
  # L=L
  # J=J
  # K=K
  LK=L*K
  JK=J*K
  gindex =sort(c(rep(1:14,times=4),rep(15:(K+14),times=L)))
  
  
  bicnoth<-bic.sglfit(x=x,y=y,gindex = gindex,standardize=TRUE,intercept=TRUE,lambda.factor=0.01)
  beita=bicnoth$beita_hat
  b0=bicnoth$b0_hat
  gi=bicnoth$gi
  
  beita_hat=c(b0,beita)
  
  coll=matrix(nrow=1,ncol=0)
  for(i in 1:(LK+57)){
    if(beita_hat[i]!=0){
      coll=cbind(coll,i)
    }
    else{
      coll=coll
    }
  }
  coaa=length(coll)
  coll=c(coll,rep(0,times=(20-coaa)))
  coll=as.numeric(coll)
  
  
  return(list(beita_hat=beita_hat,gi=gi,coll=coll))
}

###预测###
pre_noth<-function(y,x,beita_hat,L,J,K){
  LK=L*K
  JK=J*K
  slo=1
  
  X<-cbind(slo,x)
  et_noth=sum((y-as.numeric(X%*%beita_hat)))
  rmse_noth=sum((y-as.numeric(X%*%beita_hat))^2)
  yhat=as.numeric(X%*%beita_hat)
  return(list(rmse_noth=rmse_noth,et_noth=et_noth,yhat=yhat))
}

###AR1####
ar1<-function(y_train,y_test,tt){
  AR1=arima(y_train,order=c(1,0,0),include.mean=T,method="CSS-ML")
  coef=AR1$coef[1]
  intercept=AR1$coef[2]
  et=coef*y_train[tt]+intercept-y_test
  rmse=sum((coef*y_train[tt]+intercept-y_test)^2)
  yhat=as.numeric(coef*y_train[tt]+intercept)
  return(list(rmse=rmse,et=et,yhat=yhat))
}
