DGP<-function(J,h,L){
  # J=12
  # h=0
  # L=3
  data_x_M=read_excel('~/Desktop/HDMIDASCDT-46/codes and data/empirical/data/data_x_M.xlsx')
  data_x=data_x_M[,-1]
  data_x=as.matrix(data_x)
  fits=softImpute(data_x,rank.max=6,trace=FALSE,type="als")
  data_x_train=complete(data_x,fits)
  data_x_train=cbind(data_x_M[,1],data_x_train)
  data_x_train=data.frame(data_x_train)
  data_x_train[-1,(5:8)]<-data_x_train[-1,(5:8)]-data_x_train[-nrow(data_x_train),(5:8)]
  data_x_train[,(9:18)]<-log(data_x_train[,(9:18)])
  data_x_train[-1,(19:28)]<-log(data_x_train[-1,(19:28)])-log(data_x_train[-nrow(data_x_train),(19:28)])
  data_x_train[-1,(29:44)]<-log(data_x_train[-1,(29:44)])-log(data_x_train[-nrow(data_x_train),(29:44)])
  data_x_train[-1,(29:44)]<-data_x_train[-1,(29:44)]-data_x_train[-nrow(data_x_train),(29:44)]
  
  
  data_x_Q= read_excel('~/Desktop/HDMIDASCDT-46/codes and data/empirical/data/data_x_Q.xlsx')
  data_x_Q=data.frame(data_x_Q)
  # 将NA值替换为0
  data_x_Q[is.na(data_x_Q)] <- 0
  data_x_Q[-1,(2:5)] <- ((data_x_Q[-1, (2:5)]/data_x_Q[-dim(data_x_Q)[1], (2:5)])^4-1)*100
  data_x_Q[-1,(6:15)]<-log(data_x_Q[-1,(6:15)])-log(data_x_Q[-nrow(data_x_Q),(6:15)])
  data_y_train=data_x_Q[,1:2]
  
  
  
  
  data_zt= read_excel('~/Desktop/HDMIDASCDT-46/codes and data/empirical/data/data_zt_train.xlsx')
  data_z=data_zt[,-1]
  data_z=as.matrix(data_z)
  fits=softImpute(data_z,rank.max=6,trace=FALSE,type="als")
  data_zt_train=complete(data_z,fits)
  data_zt_train=cbind(data_zt[,1],data_zt_train)
  data_zt_train=data.frame(data_zt_train)
  data_zt_train[-1,(4:6)]<-data_zt_train[-1,(4:6)]-data_zt_train[-nrow(data_zt_train),(4:6)]
  data_zt_train[-1,(7:11)]<-log(data_zt_train[-1,(7:10)])-log(data_zt_train[-nrow(data_zt_train),(7:10)])
  data_zt_train[-1,(11)]<-data_zt_train[-1,(11)]-data_zt_train[-nrow(data_zt_train),(11)]
  
  est.start <- as.Date("1983-01-01")
  est.end <- as.Date("2022-12-01")
  
  mix1=mixed_freq_data(data_y_train[,2], as.Date(data_y_train[,1]), data_x_train[,2],
                       as.Date(data_x_train[,1]), x.lag = J, y.lag = 4, horizon = h,
                       est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix2=mixed_freq_data(data_x_Q[,3], as.Date(data_x_Q[,1]), data.x=data_x_train[,3], data.xdate=as.Date(data_x_train[,1]), x.lag = J, y.lag = 4,horizon = h,
                       est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix3=mixed_freq_data(data_x_Q[,4], as.Date(data_x_Q[,1]),  data.x=data_x_train[,4], data.xdate=as.Date(data_x_train[,1]), x.lag = J,y.lag = 4, horizon = h,
                       est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix4=mixed_freq_data(data_x_Q[,5], as.Date(data_x_Q[,1]), data.x=data_x_train[,5], data.xdate=as.Date(data_x_train[,1]), x.lag = J,y.lag = 4, horizon = h,
                       est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix5=mixed_freq_data(data_x_Q[,6], as.Date(data_x_Q[,1]), data.x=data_x_train[,6], data.xdate=as.Date(data_x_train[,1]), x.lag = J,y.lag = 4, horizon = h,
                       est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix6=mixed_freq_data(data_x_Q[,7], as.Date(data_x_Q[,1]), data.x=data_x_train[,7], data.xdate=as.Date(data_x_train[,1]), x.lag = J,y.lag = 4, horizon = h,
                       est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix7=mixed_freq_data(data_x_Q[,8], as.Date(data_x_Q[,1]), data.x=data_x_train[,8], data.xdate=as.Date(data_x_train[,1]), x.lag = J,y.lag = 4, horizon = h,
                       est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix8=mixed_freq_data(data_x_Q[,9], as.Date(data_x_Q[,1]), data.x=data_x_train[,9], data.xdate=as.Date(data_x_train[,1]), x.lag = J,y.lag = 4, horizon = h,
                       est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix9=mixed_freq_data(data_x_Q[,10], as.Date(data_x_Q[,1]), data.x=data_x_train[,10], data.xdate=as.Date(data_x_train[,1]), x.lag = J,y.lag = 4, horizon = h,
                       est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix10=mixed_freq_data(data_x_Q[,11], as.Date(data_x_Q[,1]), data.x=data_x_train[,11], data.xdate=as.Date(data_x_train[,1]), x.lag = J,y.lag = 4, horizon = h,
                        est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix11=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,12], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix12=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,13], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix13=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,14], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix14=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,15], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix15=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,16], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix16=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,17], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix17=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,18], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix18=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,19], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix19=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,20], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix20=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,21], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix21=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,22], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix22=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,23], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix23=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,24], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix24=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,25], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix25=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,26], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix26=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,27], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix27=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,28], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix28=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,29], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix29=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,30], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix30=mixed_freq_data(data_x_Q[,12], as.Date(data_x_Q[,1]), data.x=data_x_train[,31], data.xdate=as.Date(data_x_train[,1]), x.lag = J,y.lag = 4, horizon = h,
                        est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix31=mixed_freq_data(data_x_Q[,13], as.Date(data_x_Q[,1]), data.x=data_x_train[,32], data.xdate=as.Date(data_x_train[,1]), x.lag = J,y.lag = 4, horizon = h,
                        est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix32=mixed_freq_data(data_x_Q[,14], as.Date(data_x_Q[,1]), data.x=data_x_train[,33], data.xdate=as.Date(data_x_train[,1]), x.lag = J,y.lag = 4, horizon = h,
                        est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix33=mixed_freq_data(data_x_Q[,15], as.Date(data_x_Q[,1]), data.x=data_x_train[,34], data.xdate=as.Date(data_x_train[,1]), x.lag = J,y.lag = 4, horizon = h,
                        est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix34=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,35], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix35=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,36], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix36=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,37], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix37=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,38], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix38=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,39], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix39=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,40], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix40=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,41], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix41=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,42], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix42=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,43], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  mix43=mixed_freq_data_single(data.refdate=as.Date(data_y_train[,1]), data.x=data_x_train[,44], data.xdate=as.Date(data_x_train[,1]), x.lag = J, horizon = h,
                               est.start=est.start, est.end=est.end, disp.flag = FALSE)
  
  
  data_x_trainend=data.frame(cbind(mix1[["est.lag.y"]],mix2[["est.lag.y"]],mix3[["est.lag.y"]],mix4[["est.lag.y"]],mix5[["est.lag.y"]],mix6[["est.lag.y"]],mix7[["est.lag.y"]],mix8[["est.lag.y"]],mix9[["est.lag.y"]],mix10[["est.lag.y"]],mix30[["est.lag.y"]],mix31[["est.lag.y"]],mix32[["est.lag.y"]],mix33[["est.lag.y"]],mix1[["est.x"]],mix2[["est.x"]],mix3[["est.x"]],mix4[["est.x"]],mix5[["est.x"]],mix6[["est.x"]],mix7[["est.x"]],mix8[["est.x"]],mix9[["est.x"]],mix10[["est.x"]],mix11[["est.x"]],mix12[["est.x"]],mix13[["est.x"]],
                                   mix14[["est.x"]],mix15[["est.x"]],mix16[["est.x"]],mix17[["est.x"]],mix18[["est.x"]],mix19[["est.x"]],mix20[["est.x"]],mix21[["est.x"]],mix22[["est.x"]],mix23[["est.x"]],mix24[["est.x"]],mix25[["est.x"]],mix26[["est.x"]],mix27[["est.x"]],mix28[["est.x"]],mix29[["est.x"]],mix30[["est.x"]],mix31[["est.x"]],mix32[["est.x"]],mix33[["est.x"]],mix34[["est.x"]],mix35[["est.x"]],mix36[["est.x"]],mix37[["est.x"]],mix38[["est.x"]],mix39[["est.x"]],mix40[["est.x"]],mix41[["est.x"]],mix42[["est.x"]],mix43[["est.x"]]))
  data_x_a=data_x_trainend[,1:56]
  data_x_b=data_x_trainend[,57:572]
  data_x_a=as.matrix(data_x_a)
  data_x_b=as.matrix(data_x_b)
  degree <-L-1
  jmax <- J
  Q_V<-matrix(lb(degree = degree,jmax = jmax)/jmax,ncol = L,nrow = jmax)
  x1=matrix(nrow=160,ncol=0)
  dim(data_x_b)<-c(160,12,43)
  for(i in 1:43){
    x1_sse=data_x_b[,,i]%*%Q_V
    x1=cbind(x1,x1_sse)
  }
  data_x_trainfinal=cbind(data_x_a,x1)
  data_x_trainfinal=as.matrix(data_x_trainfinal)
  
  return(list(data_y_train=data_y_train,data_zt_train=data_zt_train,data_x_trainfinal=data_x_trainfinal))
}