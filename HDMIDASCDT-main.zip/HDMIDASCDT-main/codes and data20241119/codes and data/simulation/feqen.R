library("pracma")
library("glmnet")
library("msgps")
library("ncvreg")
library("msaenet")
library('midasml')
feqen<-function(y_train,x_train,slo_train,q_train,zt_train,J,L,K,pz,LK,JK,tt,method){
  # y_train=dgps1$y_train
  # x_train=dgps1$x_train
  # slo_train=dgps1$slo_train
  # q_train=dgps1$q_train
  # zt_train=dgps1$zt_train
  # J=dgps1$J
  # L=dgps1$L
  # K=dgps1$K
  # pz=dgps1$pz
  # LK=dgps1$LK
  # JK=dgps1$JK
  # tt=dgps1$tt
  
  p=0
  f1=0
  f2=0
  tp=0
  fp=0
  tn=0
  fn=0
  
  LK=L*K
  JK=J*K
  
  A=x_train
  x20=matrix(nrow=0,ncol=((LK)*(pz)))
  for(i in 1:(tt)){
    xizj=kronecker(A[i,],zt_train[i,])
    x20=rbind(x20,xizj)
  }
  x10=matrix(nrow=0,ncol=(LK))
  for(i in 1:(tt)){
    xiq=A[i,]*q_train[i]
    x10=rbind(x10,xiq)
  }
  x20=as.matrix(x20)
  x10=as.matrix(x10)
  
  B=cbind(zt_train,A,q_train,x10,x20)
  B=as.matrix(B)
  dim=ncol(B)
  
  if(method=='alasso'){
    alasso_fit=msgps(B,y_train,penalty="alasso",alpha=0,lambda=0.001,DFtype="MODIFIED",intercept=TRUE,stand.coef=TRUE)
    gamma_est=alasso_fit$dfbic_result$coef[2:(pz+1)]
    
  }
  
  if(method=='scad'){
    penal=rep(0,times=dim)
    penal[2:(pz+1)]=1
    cv.fit=cv.ncvreg(B,y_train,family="gaussian",penalty="SCAD",alpha=1,lambda.min=0.05,gamma=3.7,penal.factor=penal)
    gamma=coef(cv.fit)
    gamma_est=gamma[2:(pz+1)]
    
  }
  
  if(method=='lasso'){
  
    uplasso=cv.glmnet(B,y_train,alpha=1,lambda.min.ratio=0.01)
    gamma=coef(uplasso,s="lambda.1se")
    gamma_est=gamma[2:(pz+1)]

  }
  
  if (gamma_est[1]!=0&&gamma_est[2]!=0&&gamma_est[3]==0&&gamma_est[4]==0&&gamma_est[5]==0){
    p=p+1
  }
  else{
    p=p
  }
  
  if (gamma_est[3]!=0||gamma_est[4]!=0||gamma_est[5]!=0) {
    
    f1=f1+1
    
  }else{
    f1=f1
  }
  
  if (gamma_est[1]==0||gamma_est[2]==0 ) {
    
    f2=f2+1
    
  }else{
    f2=f2
  }
  
  
  if (gamma_est[1]!=0  && gamma_est[2]!=0 ) {
    
    tp=tp+1
    
  }else{
    tp=tp
  }
  
  if (gamma_est[3]!=0 || gamma_est[4]!=0  || gamma_est[5]!=0) {
    
    fp=fp+1
    
  }else{
    fp=fp
  }
  
  if (gamma_est[3]==0  && gamma_est[4]==0   &&  gamma_est[5]==0) {
    
    tn=tn+1
    
  }else{
    tn=tn
  }
  
  if (gamma_est[1]==0 || gamma_est[2]==0 ) {
    
    fn=fn+1
    
  }else{
    fn=fn
  }
  return(list(p=p,f1=f1,f2=f2,tp=tp,fp=fp,tn=tn,fn=fn))
}