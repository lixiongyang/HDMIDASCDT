rm(list=ls())
####选择影响门槛的协变量#####
source('~/Desktop/HDMIDASCDT-46/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-46/codes and data/simulation/feqen.R')
####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <- 1000
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)
####simulation_result9####
cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
feq1<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
               .combine='rbind',.errorhandling = "pass")%dopar% {
                 dgps1<-dgp(tt=100,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='independent',e="gaussian")
                 dgps2<-dgp(tt=200,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='independent',e="gaussian")
                 dgps3<-dgp(tt=500,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='independent',e="gaussian")
                 feqen1=feqen(dgps1$y_train,dgps1$x_train,dgps1$slo_train,dgps1$q_train,dgps1$zt_train,dgps1$J,dgps1$L,dgps1$K,dgps1$pz,dgps1$LK,dgps1$JK,dgps1$tt,method='alasso')
                 feqen2=feqen(dgps1$y_train,dgps1$x_train,dgps1$slo_train,dgps1$q_train,dgps1$zt_train,dgps1$J,dgps1$L,dgps1$K,dgps1$pz,dgps1$LK,dgps1$JK,dgps1$tt,method='lasso')
                 feqen3=feqen(dgps1$y_train,dgps1$x_train,dgps1$slo_train,dgps1$q_train,dgps1$zt_train,dgps1$J,dgps1$L,dgps1$K,dgps1$pz,dgps1$LK,dgps1$JK,dgps1$tt,method='scad')
                 feqen4=feqen(dgps2$y_train,dgps2$x_train,dgps2$slo_train,dgps2$q_train,dgps2$zt_train,dgps2$J,dgps2$L,dgps2$K,dgps2$pz,dgps2$LK,dgps2$JK,dgps2$tt,method='alasso')
                 feqen5=feqen(dgps2$y_train,dgps2$x_train,dgps2$slo_train,dgps2$q_train,dgps2$zt_train,dgps2$J,dgps2$L,dgps2$K,dgps2$pz,dgps2$LK,dgps2$JK,dgps2$tt,method='lasso')
                 feqen6=feqen(dgps2$y_train,dgps2$x_train,dgps2$slo_train,dgps2$q_train,dgps2$zt_train,dgps2$J,dgps2$L,dgps2$K,dgps2$pz,dgps2$LK,dgps2$JK,dgps2$tt,method='scad')
                 feqen7=feqen(dgps3$y_train,dgps3$x_train,dgps3$slo_train,dgps3$q_train,dgps3$zt_train,dgps3$J,dgps3$L,dgps3$K,dgps3$pz,dgps3$LK,dgps3$JK,dgps3$tt,method='alasso')
                 feqen8=feqen(dgps3$y_train,dgps3$x_train,dgps3$slo_train,dgps3$q_train,dgps3$zt_train,dgps3$J,dgps3$L,dgps3$K,dgps3$pz,dgps3$LK,dgps3$JK,dgps3$tt,method='lasso')
                 feqen9=feqen(dgps3$y_train,dgps3$x_train,dgps3$slo_train,dgps3$q_train,dgps3$zt_train,dgps3$J,dgps3$L,dgps3$K,dgps3$pz,dgps3$LK,dgps3$JK,dgps3$tt,method='scad')
                 return(c(feqen1$p,feqen1$f1,feqen1$f2,feqen1$tp,feqen1$fp,feqen1$tn,feqen1$fn,feqen2$p,feqen2$f1,feqen2$f2,feqen2$tp,feqen2$fp,feqen2$tn,feqen2$fn,feqen3$p,feqen3$f1,feqen3$f2,feqen3$tp,feqen3$fp,feqen3$tn,feqen3$fn,
                          feqen4$p,feqen4$f1,feqen4$f2,feqen4$tp,feqen4$fp,feqen4$tn,feqen4$fn,feqen5$p,feqen5$f1,feqen5$f2,feqen5$tp,feqen5$fp,feqen5$tn,feqen5$fn,feqen6$p,feqen6$f1,feqen6$f2,feqen6$tp,feqen6$fp,feqen6$tn,feqen6$fn,
                          feqen7$p,feqen7$f1,feqen7$f2,feqen7$tp,feqen7$fp,feqen7$tn,feqen7$fn,feqen8$p,feqen8$f1,feqen8$f2,feqen8$tp,feqen8$fp,feqen8$tn,feqen8$fn,feqen9$p,feqen9$f1,feqen9$f2,feqen9$tp,feqen9$fp,feqen9$tn,feqen9$fn))
               }
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
feq_fin= matrix(0,nrow = 1,ncol =63)
feq_fin= round(colSums(feq1),3)

ps1=feq_fin[1]/1000
fnz1=feq_fin[2]/1000
fz1=feq_fin[3]/1000
tpr1=feq_fin[4]/(feq_fin[4]+feq_fin[7])
fpr1=feq_fin[5]/(feq_fin[5]+feq_fin[6])
tnr1=feq_fin[6]/(feq_fin[6]+feq_fin[5])
fnr1=feq_fin[7]/(feq_fin[7]+feq_fin[4])
precision1=feq_fin[4]/(feq_fin[4]+feq_fin[5])
recall1=feq_fin[4]/(feq_fin[4]+feq_fin[7])
fscore1=2*precision1*recall1/(precision1+recall1)
fOr1=feq_fin[7]/(feq_fin[7]+feq_fin[6])
fdr1=feq_fin[5]/(feq_fin[4]+feq_fin[5])

ps2=feq_fin[8]/1000
fnz2=feq_fin[9]/1000
fz2=feq_fin[10]/1000
tpr2=feq_fin[11]/(feq_fin[11]+feq_fin[14])
fpr2=feq_fin[12]/(feq_fin[12]+feq_fin[13])
tnr2=feq_fin[13]/(feq_fin[13]+feq_fin[12])
fnr2=feq_fin[14]/(feq_fin[14]+feq_fin[11])
precision2=feq_fin[11]/(feq_fin[11]+feq_fin[12])
recall2=feq_fin[11]/(feq_fin[11]+feq_fin[14])
fscore2=2*precision2*recall2/(precision2+recall2)
fOr2=feq_fin[14]/(feq_fin[14]+feq_fin[13])
fdr2=feq_fin[12]/(feq_fin[11]+feq_fin[12])

ps3=feq_fin[15]/1000
fnz3=feq_fin[16]/1000
fz3=feq_fin[17]/1000
tpr3=feq_fin[18]/(feq_fin[18]+feq_fin[21])
fpr3=feq_fin[19]/(feq_fin[19]+feq_fin[20])
tnr3=feq_fin[20]/(feq_fin[20]+feq_fin[19])
fnr3=feq_fin[21]/(feq_fin[21]+feq_fin[18])
precision3=feq_fin[18]/(feq_fin[18]+feq_fin[19])
recall3=feq_fin[18]/(feq_fin[18]+feq_fin[21])
fscore3=2*precision3*recall3/(precision3+recall3)
fOr3=feq_fin[21]/(feq_fin[21]+feq_fin[20])
fdr3=feq_fin[19]/(feq_fin[18]+feq_fin[19])

ps4=feq_fin[22]/1000
fnz4=feq_fin[23]/1000
fz4=feq_fin[24]/1000
tpr4=feq_fin[25]/(feq_fin[25]+feq_fin[28])
fpr4=feq_fin[26]/(feq_fin[26]+feq_fin[27])
tnr4=feq_fin[27]/(feq_fin[27]+feq_fin[26])
fnr4=feq_fin[28]/(feq_fin[28]+feq_fin[25])
precision4=feq_fin[25]/(feq_fin[25]+feq_fin[26])
recall4=feq_fin[25]/(feq_fin[25]+feq_fin[28])
fscore4=2*precision4*recall4/(precision4+recall4)
fOr4=feq_fin[28]/(feq_fin[28]+feq_fin[27])
fdr4=feq_fin[26]/(feq_fin[25]+feq_fin[26])

ps5=feq_fin[29]/1000
fnz5=feq_fin[30]/1000
fz5=feq_fin[31]/1000
tpr5=feq_fin[32]/(feq_fin[32]+feq_fin[35])
fpr5=feq_fin[33]/(feq_fin[33]+feq_fin[34])
tnr5=feq_fin[34]/(feq_fin[34]+feq_fin[33])
fnr5=feq_fin[35]/(feq_fin[35]+feq_fin[32])
precision5=feq_fin[32]/(feq_fin[32]+feq_fin[33])
recall5=feq_fin[32]/(feq_fin[32]+feq_fin[35])
fscore5=2*precision5*recall5/(precision5+recall5)
fOr5=feq_fin[35]/(feq_fin[35]+feq_fin[34])
fdr5=feq_fin[33]/(feq_fin[32]+feq_fin[33])

ps6=feq_fin[36]/1000
fnz6=feq_fin[37]/1000
fz6=feq_fin[38]/1000
tpr6=feq_fin[39]/(feq_fin[39]+feq_fin[42])
fpr6=feq_fin[40]/(feq_fin[40]+feq_fin[41])
tnr6=feq_fin[41]/(feq_fin[41]+feq_fin[40])
fnr6=feq_fin[42]/(feq_fin[42]+feq_fin[39])
precision6=feq_fin[39]/(feq_fin[39]+feq_fin[40])
recall6=feq_fin[39]/(feq_fin[39]+feq_fin[42])
fscore6=2*precision6*recall6/(precision6+recall6)
fOr6=feq_fin[42]/(feq_fin[42]+feq_fin[41])
fdr6=feq_fin[40]/(feq_fin[39]+feq_fin[40])

ps7=feq_fin[43]/1000
fnz7=feq_fin[44]/1000
fz7=feq_fin[45]/1000
tpr7=feq_fin[46]/(feq_fin[46]+feq_fin[49])
fpr7=feq_fin[47]/(feq_fin[47]+feq_fin[48])
tnr7=feq_fin[48]/(feq_fin[48]+feq_fin[47])
fnr7=feq_fin[49]/(feq_fin[49]+feq_fin[46])
precision7=feq_fin[46]/(feq_fin[46]+feq_fin[47])
recall7=feq_fin[46]/(feq_fin[46]+feq_fin[49])
fscore7=2*precision7*recall7/(precision7+recall7)
fOr7=feq_fin[49]/(feq_fin[49]+feq_fin[48])
fdr7=feq_fin[47]/(feq_fin[46]+feq_fin[47])

ps8=feq_fin[50]/1000
fnz8=feq_fin[51]/1000
fz8=feq_fin[52]/1000
tpr8=feq_fin[53]/(feq_fin[53]+feq_fin[56])
fpr8=feq_fin[54]/(feq_fin[54]+feq_fin[55])
tnr8=feq_fin[55]/(feq_fin[55]+feq_fin[54])
fnr8=feq_fin[56]/(feq_fin[56]+feq_fin[53])
precision8=feq_fin[53]/(feq_fin[53]+feq_fin[54])
recall8=feq_fin[53]/(feq_fin[53]+feq_fin[56])
fscore8=2*precision8*recall8/(precision8+recall8)
fOr8=feq_fin[56]/(feq_fin[56]+feq_fin[55])
fdr8=feq_fin[54]/(feq_fin[53]+feq_fin[54])

ps9=feq_fin[57]/1000
fnz9=feq_fin[58]/1000
fz9=feq_fin[59]/1000
tpr9=feq_fin[60]/(feq_fin[60]+feq_fin[63])
fpr9=feq_fin[61]/(feq_fin[61]+feq_fin[62])
tnr9=feq_fin[62]/(feq_fin[62]+feq_fin[61])
fnr9=feq_fin[63]/(feq_fin[63]+feq_fin[60])
precision9=feq_fin[60]/(feq_fin[60]+feq_fin[61])
recall9=feq_fin[60]/(feq_fin[60]+feq_fin[63])
fscore9=2*precision9*recall9/(precision9+recall9)
fOr9=feq_fin[63]/(feq_fin[63]+feq_fin[62])
fdr9=feq_fin[61]/(feq_fin[60]+feq_fin[61])

indexalasso100=cbind(ps1,fnz1,fz1,tpr1,fpr1,tnr1,fnr1,precision1,fscore1,fOr1,fdr1)
indexlasso100=cbind(ps2,fnz2,fz2,tpr2,fpr2,tnr2,fnr2,precision2,fscore2,fOr2,fdr2)
indexscad100=cbind(ps3,fnz3,fz3,tpr3,fpr3,tnr3,fnr3,precision3,fscore3,fOr3,fdr3)
indexalasso200=cbind(ps4,fnz4,fz4,tpr4,fpr4,tnr4,fnr4,precision4,fscore4,fOr4,fdr4)
indexlasso200=cbind(ps5,fnz5,fz5,tpr5,fpr5,tnr5,fnr5,precision5,fscore5,fOr5,fdr5)
indexscad200=cbind(ps6,fnz6,fz6,tpr6,fpr6,tnr6,fnr6,precision6,fscore6,fOr6,fdr6)
indexalasso500=cbind(ps7,fnz7,fz7,tpr7,fpr7,tnr7,fnr7,precision7,fscore7,fOr7,fdr7)
indexlasso500=cbind(ps8,fnz8,fz8,tpr8,fpr8,tnr8,fnr8,precision8,fscore8,fOr8,fdr8)
indexscad500=cbind(ps9,fnz9,fz9,tpr9,fpr9,tnr9,fnr9,precision9,fscore9,fOr9,fdr9)

save.image('~/Desktop/HDMIDASCDT-46/codes and data/simulation/simulation_choosegamma.Rdata')


####选择影响门槛的协变量#####
source('~/Desktop/HDMIDASCDT-38/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-38/codes and data/simulation/feqen.R')
####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <- 1000
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)
####simulation_result9####
cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
feq1<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
               .combine='rbind',.errorhandling = "pass")%dopar% {
                 dgps1<-dgp(tt=100,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='dependent',e="non-gaussian")
                 dgps2<-dgp(tt=200,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='dependent',e="non-gaussian")
                 dgps3<-dgp(tt=500,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='dependent',e="non-gaussian")
                 feqen1=feqen(dgps1$y_train,dgps1$x_train,dgps1$slo_train,dgps1$q_train,dgps1$zt_train,dgps1$J,dgps1$L,dgps1$K,dgps1$pz,dgps1$LK,dgps1$JK,dgps1$tt,method='alasso')
                 feqen2=feqen(dgps1$y_train,dgps1$x_train,dgps1$slo_train,dgps1$q_train,dgps1$zt_train,dgps1$J,dgps1$L,dgps1$K,dgps1$pz,dgps1$LK,dgps1$JK,dgps1$tt,method='lasso')
                 feqen3=feqen(dgps1$y_train,dgps1$x_train,dgps1$slo_train,dgps1$q_train,dgps1$zt_train,dgps1$J,dgps1$L,dgps1$K,dgps1$pz,dgps1$LK,dgps1$JK,dgps1$tt,method='scad')
                 feqen4=feqen(dgps2$y_train,dgps2$x_train,dgps2$slo_train,dgps2$q_train,dgps2$zt_train,dgps2$J,dgps2$L,dgps2$K,dgps2$pz,dgps2$LK,dgps2$JK,dgps2$tt,method='alasso')
                 feqen5=feqen(dgps2$y_train,dgps2$x_train,dgps2$slo_train,dgps2$q_train,dgps2$zt_train,dgps2$J,dgps2$L,dgps2$K,dgps2$pz,dgps2$LK,dgps2$JK,dgps2$tt,method='lasso')
                 feqen6=feqen(dgps2$y_train,dgps2$x_train,dgps2$slo_train,dgps2$q_train,dgps2$zt_train,dgps2$J,dgps2$L,dgps2$K,dgps2$pz,dgps2$LK,dgps2$JK,dgps2$tt,method='scad')
                 feqen7=feqen(dgps3$y_train,dgps3$x_train,dgps3$slo_train,dgps3$q_train,dgps3$zt_train,dgps3$J,dgps3$L,dgps3$K,dgps3$pz,dgps3$LK,dgps3$JK,dgps3$tt,method='alasso')
                 feqen8=feqen(dgps3$y_train,dgps3$x_train,dgps3$slo_train,dgps3$q_train,dgps3$zt_train,dgps3$J,dgps3$L,dgps3$K,dgps3$pz,dgps3$LK,dgps3$JK,dgps3$tt,method='lasso')
                 feqen9=feqen(dgps3$y_train,dgps3$x_train,dgps3$slo_train,dgps3$q_train,dgps3$zt_train,dgps3$J,dgps3$L,dgps3$K,dgps3$pz,dgps3$LK,dgps3$JK,dgps3$tt,method='scad')
                 return(c(feqen1$p,feqen1$f1,feqen1$f2,feqen1$tp,feqen1$fp,feqen1$tn,feqen1$fn,feqen2$p,feqen2$f1,feqen2$f2,feqen2$tp,feqen2$fp,feqen2$tn,feqen2$fn,feqen3$p,feqen3$f1,feqen3$f2,feqen3$tp,feqen3$fp,feqen3$tn,feqen3$fn,
                          feqen4$p,feqen4$f1,feqen4$f2,feqen4$tp,feqen4$fp,feqen4$tn,feqen4$fn,feqen5$p,feqen5$f1,feqen5$f2,feqen5$tp,feqen5$fp,feqen5$tn,feqen5$fn,feqen6$p,feqen6$f1,feqen6$f2,feqen6$tp,feqen6$fp,feqen6$tn,feqen6$fn,
                          feqen7$p,feqen7$f1,feqen7$f2,feqen7$tp,feqen7$fp,feqen7$tn,feqen7$fn,feqen8$p,feqen8$f1,feqen8$f2,feqen8$tp,feqen8$fp,feqen8$tn,feqen8$fn,feqen9$p,feqen9$f1,feqen9$f2,feqen9$tp,feqen9$fp,feqen9$tn,feqen9$fn))
               }
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
feq_fin= matrix(0,nrow = 1,ncol =63)
feq_fin= round(colSums(feq1),3)

ps1=feq_fin[1]/1000
fnz1=feq_fin[2]/1000
fz1=feq_fin[3]/1000
tpr1=feq_fin[4]/(feq_fin[4]+feq_fin[7])
fpr1=feq_fin[5]/(feq_fin[5]+feq_fin[6])
tnr1=feq_fin[6]/(feq_fin[6]+feq_fin[5])
fnr1=feq_fin[7]/(feq_fin[7]+feq_fin[4])
precision1=feq_fin[4]/(feq_fin[4]+feq_fin[5])
recall1=feq_fin[4]/(feq_fin[4]+feq_fin[7])
fscore1=2*precision1*recall1/(precision1+recall1)
fOr1=feq_fin[7]/(feq_fin[7]+feq_fin[6])
fdr1=feq_fin[5]/(feq_fin[4]+feq_fin[5])

ps2=feq_fin[8]/1000
fnz2=feq_fin[9]/1000
fz2=feq_fin[10]/1000
tpr2=feq_fin[11]/(feq_fin[11]+feq_fin[14])
fpr2=feq_fin[12]/(feq_fin[12]+feq_fin[13])
tnr2=feq_fin[13]/(feq_fin[13]+feq_fin[12])
fnr2=feq_fin[14]/(feq_fin[14]+feq_fin[11])
precision2=feq_fin[11]/(feq_fin[11]+feq_fin[12])
recall2=feq_fin[11]/(feq_fin[11]+feq_fin[14])
fscore2=2*precision2*recall2/(precision2+recall2)
fOr2=feq_fin[14]/(feq_fin[14]+feq_fin[13])
fdr2=feq_fin[12]/(feq_fin[11]+feq_fin[12])

ps3=feq_fin[15]/1000
fnz3=feq_fin[16]/1000
fz3=feq_fin[17]/1000
tpr3=feq_fin[18]/(feq_fin[18]+feq_fin[21])
fpr3=feq_fin[19]/(feq_fin[19]+feq_fin[20])
tnr3=feq_fin[20]/(feq_fin[20]+feq_fin[19])
fnr3=feq_fin[21]/(feq_fin[21]+feq_fin[18])
precision3=feq_fin[18]/(feq_fin[18]+feq_fin[19])
recall3=feq_fin[18]/(feq_fin[18]+feq_fin[21])
fscore3=2*precision3*recall3/(precision3+recall3)
fOr3=feq_fin[21]/(feq_fin[21]+feq_fin[20])
fdr3=feq_fin[19]/(feq_fin[18]+feq_fin[19])

ps4=feq_fin[22]/1000
fnz4=feq_fin[23]/1000
fz4=feq_fin[24]/1000
tpr4=feq_fin[25]/(feq_fin[25]+feq_fin[28])
fpr4=feq_fin[26]/(feq_fin[26]+feq_fin[27])
tnr4=feq_fin[27]/(feq_fin[27]+feq_fin[26])
fnr4=feq_fin[28]/(feq_fin[28]+feq_fin[25])
precision4=feq_fin[25]/(feq_fin[25]+feq_fin[26])
recall4=feq_fin[25]/(feq_fin[25]+feq_fin[28])
fscore4=2*precision4*recall4/(precision4+recall4)
fOr4=feq_fin[28]/(feq_fin[28]+feq_fin[27])
fdr4=feq_fin[26]/(feq_fin[25]+feq_fin[26])

ps5=feq_fin[29]/1000
fnz5=feq_fin[30]/1000
fz5=feq_fin[31]/1000
tpr5=feq_fin[32]/(feq_fin[32]+feq_fin[35])
fpr5=feq_fin[33]/(feq_fin[33]+feq_fin[34])
tnr5=feq_fin[34]/(feq_fin[34]+feq_fin[33])
fnr5=feq_fin[35]/(feq_fin[35]+feq_fin[32])
precision5=feq_fin[32]/(feq_fin[32]+feq_fin[33])
recall5=feq_fin[32]/(feq_fin[32]+feq_fin[35])
fscore5=2*precision5*recall5/(precision5+recall5)
fOr5=feq_fin[35]/(feq_fin[35]+feq_fin[34])
fdr5=feq_fin[33]/(feq_fin[32]+feq_fin[33])

ps6=feq_fin[36]/1000
fnz6=feq_fin[37]/1000
fz6=feq_fin[38]/1000
tpr6=feq_fin[39]/(feq_fin[39]+feq_fin[42])
fpr6=feq_fin[40]/(feq_fin[40]+feq_fin[41])
tnr6=feq_fin[41]/(feq_fin[41]+feq_fin[40])
fnr6=feq_fin[42]/(feq_fin[42]+feq_fin[39])
precision6=feq_fin[39]/(feq_fin[39]+feq_fin[40])
recall6=feq_fin[39]/(feq_fin[39]+feq_fin[42])
fscore6=2*precision6*recall6/(precision6+recall6)
fOr6=feq_fin[42]/(feq_fin[42]+feq_fin[41])
fdr6=feq_fin[40]/(feq_fin[39]+feq_fin[40])

ps7=feq_fin[43]/1000
fnz7=feq_fin[44]/1000
fz7=feq_fin[45]/1000
tpr7=feq_fin[46]/(feq_fin[46]+feq_fin[49])
fpr7=feq_fin[47]/(feq_fin[47]+feq_fin[48])
tnr7=feq_fin[48]/(feq_fin[48]+feq_fin[47])
fnr7=feq_fin[49]/(feq_fin[49]+feq_fin[46])
precision7=feq_fin[46]/(feq_fin[46]+feq_fin[47])
recall7=feq_fin[46]/(feq_fin[46]+feq_fin[49])
fscore7=2*precision7*recall7/(precision7+recall7)
fOr7=feq_fin[49]/(feq_fin[49]+feq_fin[48])
fdr7=feq_fin[47]/(feq_fin[46]+feq_fin[47])

ps8=feq_fin[50]/1000
fnz8=feq_fin[51]/1000
fz8=feq_fin[52]/1000
tpr8=feq_fin[53]/(feq_fin[53]+feq_fin[56])
fpr8=feq_fin[54]/(feq_fin[54]+feq_fin[55])
tnr8=feq_fin[55]/(feq_fin[55]+feq_fin[54])
fnr8=feq_fin[56]/(feq_fin[56]+feq_fin[53])
precision8=feq_fin[53]/(feq_fin[53]+feq_fin[54])
recall8=feq_fin[53]/(feq_fin[53]+feq_fin[56])
fscore8=2*precision8*recall8/(precision8+recall8)
fOr8=feq_fin[56]/(feq_fin[56]+feq_fin[55])
fdr8=feq_fin[54]/(feq_fin[53]+feq_fin[54])

ps9=feq_fin[57]/1000
fnz9=feq_fin[58]/1000
fz9=feq_fin[59]/1000
tpr9=feq_fin[60]/(feq_fin[60]+feq_fin[63])
fpr9=feq_fin[61]/(feq_fin[61]+feq_fin[62])
tnr9=feq_fin[62]/(feq_fin[62]+feq_fin[61])
fnr9=feq_fin[63]/(feq_fin[63]+feq_fin[60])
precision9=feq_fin[60]/(feq_fin[60]+feq_fin[61])
recall9=feq_fin[60]/(feq_fin[60]+feq_fin[63])
fscore9=2*precision9*recall9/(precision9+recall9)
fOr9=feq_fin[63]/(feq_fin[63]+feq_fin[62])
fdr9=feq_fin[61]/(feq_fin[60]+feq_fin[61])

deindexalasso100=cbind(ps1,fnz1,fz1,tpr1,fpr1,tnr1,fnr1,precision1,fscore1,fOr1,fdr1)
deindexlasso100=cbind(ps2,fnz2,fz2,tpr2,fpr2,tnr2,fnr2,precision2,fscore2,fOr2,fdr2)
deindexscad100=cbind(ps3,fnz3,fz3,tpr3,fpr3,tnr3,fnr3,precision3,fscore3,fOr3,fdr3)
deindexalasso200=cbind(ps4,fnz4,fz4,tpr4,fpr4,tnr4,fnr4,precision4,fscore4,fOr4,fdr4)
deindexlasso200=cbind(ps5,fnz5,fz5,tpr5,fpr5,tnr5,fnr5,precision5,fscore5,fOr5,fdr5)
deindexscad200=cbind(ps6,fnz6,fz6,tpr6,fpr6,tnr6,fnr6,precision6,fscore6,fOr6,fdr6)
deindexalasso500=cbind(ps7,fnz7,fz7,tpr7,fpr7,tnr7,fnr7,precision7,fscore7,fOr7,fdr7)
deindexlasso500=cbind(ps8,fnz8,fz8,tpr8,fpr8,tnr8,fnr8,precision8,fscore8,fOr8,fdr8)
deindexscad500=cbind(ps9,fnz9,fz9,tpr9,fpr9,tnr9,fnr9,precision9,fscore9,fOr9,fdr9)


save.image('~/Desktop/HDMIDASCDT-38/codes and data/simulation/simulation_choosegamma2.Rdata')


####选择影响门槛的协变量#####
source('~/Desktop/HDMIDASCDT-38/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-38/codes and data/simulation/feqen.R')
####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <- 1000
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)
####simulation_result9####
cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
feq1<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
               .combine='rbind',.errorhandling = "pass")%dopar% {
                 dgps1<-dgp(tt=100,beta1=c(1,0,1,1,rep(0,times=87)),beta2=c(-1,-2,1,-1,rep(0,times=87)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=30,pz=5,z='independent',e="gaussian")
                 dgps2<-dgp(tt=200,beta1=c(1,0,1,1,rep(0,times=87)),beta2=c(-1,-2,1,-1,rep(0,times=87)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=30,pz=5,z='independent',e="gaussian")
                 dgps3<-dgp(tt=500,beta1=c(1,0,1,1,rep(0,times=87)),beta2=c(-1,-2,1,-1,rep(0,times=87)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=30,pz=5,z='independent',e="gaussian")
                 feqen1=feqen(dgps1$y_train,dgps1$x_train,dgps1$slo_train,dgps1$q_train,dgps1$zt_train,dgps1$J,dgps1$L,dgps1$K,dgps1$pz,dgps1$LK,dgps1$JK,dgps1$tt,method='alasso')
                 feqen2=feqen(dgps1$y_train,dgps1$x_train,dgps1$slo_train,dgps1$q_train,dgps1$zt_train,dgps1$J,dgps1$L,dgps1$K,dgps1$pz,dgps1$LK,dgps1$JK,dgps1$tt,method='lasso')
                 feqen3=feqen(dgps1$y_train,dgps1$x_train,dgps1$slo_train,dgps1$q_train,dgps1$zt_train,dgps1$J,dgps1$L,dgps1$K,dgps1$pz,dgps1$LK,dgps1$JK,dgps1$tt,method='scad')
                 feqen4=feqen(dgps2$y_train,dgps2$x_train,dgps2$slo_train,dgps2$q_train,dgps2$zt_train,dgps2$J,dgps2$L,dgps2$K,dgps2$pz,dgps2$LK,dgps2$JK,dgps2$tt,method='alasso')
                 feqen5=feqen(dgps2$y_train,dgps2$x_train,dgps2$slo_train,dgps2$q_train,dgps2$zt_train,dgps2$J,dgps2$L,dgps2$K,dgps2$pz,dgps2$LK,dgps2$JK,dgps2$tt,method='lasso')
                 feqen6=feqen(dgps2$y_train,dgps2$x_train,dgps2$slo_train,dgps2$q_train,dgps2$zt_train,dgps2$J,dgps2$L,dgps2$K,dgps2$pz,dgps2$LK,dgps2$JK,dgps2$tt,method='scad')
                 feqen7=feqen(dgps3$y_train,dgps3$x_train,dgps3$slo_train,dgps3$q_train,dgps3$zt_train,dgps3$J,dgps3$L,dgps3$K,dgps3$pz,dgps3$LK,dgps3$JK,dgps3$tt,method='alasso')
                 feqen8=feqen(dgps3$y_train,dgps3$x_train,dgps3$slo_train,dgps3$q_train,dgps3$zt_train,dgps3$J,dgps3$L,dgps3$K,dgps3$pz,dgps3$LK,dgps3$JK,dgps3$tt,method='lasso')
                 feqen9=feqen(dgps3$y_train,dgps3$x_train,dgps3$slo_train,dgps3$q_train,dgps3$zt_train,dgps3$J,dgps3$L,dgps3$K,dgps3$pz,dgps3$LK,dgps3$JK,dgps3$tt,method='scad')
                 return(c(feqen1$p,feqen1$f1,feqen1$f2,feqen1$tp,feqen1$fp,feqen1$tn,feqen1$fn,feqen2$p,feqen2$f1,feqen2$f2,feqen2$tp,feqen2$fp,feqen2$tn,feqen2$fn,feqen3$p,feqen3$f1,feqen3$f2,feqen3$tp,feqen3$fp,feqen3$tn,feqen3$fn,
                          feqen4$p,feqen4$f1,feqen4$f2,feqen4$tp,feqen4$fp,feqen4$tn,feqen4$fn,feqen5$p,feqen5$f1,feqen5$f2,feqen5$tp,feqen5$fp,feqen5$tn,feqen5$fn,feqen6$p,feqen6$f1,feqen6$f2,feqen6$tp,feqen6$fp,feqen6$tn,feqen6$fn,
                          feqen7$p,feqen7$f1,feqen7$f2,feqen7$tp,feqen7$fp,feqen7$tn,feqen7$fn,feqen8$p,feqen8$f1,feqen8$f2,feqen8$tp,feqen8$fp,feqen8$tn,feqen8$fn,feqen9$p,feqen9$f1,feqen9$f2,feqen9$tp,feqen9$fp,feqen9$tn,feqen9$fn))
               }
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
feq_fin= matrix(0,nrow = 1,ncol =63)
feq_fin= round(colSums(feq1),3)

ps1=feq_fin[1]/1000
fnz1=feq_fin[2]/1000
fz1=feq_fin[3]/1000
tpr1=feq_fin[4]/(feq_fin[4]+feq_fin[7])
fpr1=feq_fin[5]/(feq_fin[5]+feq_fin[6])
tnr1=feq_fin[6]/(feq_fin[6]+feq_fin[5])
fnr1=feq_fin[7]/(feq_fin[7]+feq_fin[4])
precision1=feq_fin[4]/(feq_fin[4]+feq_fin[5])
recall1=feq_fin[4]/(feq_fin[4]+feq_fin[7])
fscore1=2*precision1*recall1/(precision1+recall1)
fOr1=feq_fin[7]/(feq_fin[7]+feq_fin[6])
fdr1=feq_fin[5]/(feq_fin[4]+feq_fin[5])

ps2=feq_fin[8]/1000
fnz2=feq_fin[9]/1000
fz2=feq_fin[10]/1000
tpr2=feq_fin[11]/(feq_fin[11]+feq_fin[14])
fpr2=feq_fin[12]/(feq_fin[12]+feq_fin[13])
tnr2=feq_fin[13]/(feq_fin[13]+feq_fin[12])
fnr2=feq_fin[14]/(feq_fin[14]+feq_fin[11])
precision2=feq_fin[11]/(feq_fin[11]+feq_fin[12])
recall2=feq_fin[11]/(feq_fin[11]+feq_fin[14])
fscore2=2*precision2*recall2/(precision2+recall2)
fOr2=feq_fin[14]/(feq_fin[14]+feq_fin[13])
fdr2=feq_fin[12]/(feq_fin[11]+feq_fin[12])

ps3=feq_fin[15]/1000
fnz3=feq_fin[16]/1000
fz3=feq_fin[17]/1000
tpr3=feq_fin[18]/(feq_fin[18]+feq_fin[21])
fpr3=feq_fin[19]/(feq_fin[19]+feq_fin[20])
tnr3=feq_fin[20]/(feq_fin[20]+feq_fin[19])
fnr3=feq_fin[21]/(feq_fin[21]+feq_fin[18])
precision3=feq_fin[18]/(feq_fin[18]+feq_fin[19])
recall3=feq_fin[18]/(feq_fin[18]+feq_fin[21])
fscore3=2*precision3*recall3/(precision3+recall3)
fOr3=feq_fin[21]/(feq_fin[21]+feq_fin[20])
fdr3=feq_fin[19]/(feq_fin[18]+feq_fin[19])

ps4=feq_fin[22]/1000
fnz4=feq_fin[23]/1000
fz4=feq_fin[24]/1000
tpr4=feq_fin[25]/(feq_fin[25]+feq_fin[28])
fpr4=feq_fin[26]/(feq_fin[26]+feq_fin[27])
tnr4=feq_fin[27]/(feq_fin[27]+feq_fin[26])
fnr4=feq_fin[28]/(feq_fin[28]+feq_fin[25])
precision4=feq_fin[25]/(feq_fin[25]+feq_fin[26])
recall4=feq_fin[25]/(feq_fin[25]+feq_fin[28])
fscore4=2*precision4*recall4/(precision4+recall4)
fOr4=feq_fin[28]/(feq_fin[28]+feq_fin[27])
fdr4=feq_fin[26]/(feq_fin[25]+feq_fin[26])

ps5=feq_fin[29]/1000
fnz5=feq_fin[30]/1000
fz5=feq_fin[31]/1000
tpr5=feq_fin[32]/(feq_fin[32]+feq_fin[35])
fpr5=feq_fin[33]/(feq_fin[33]+feq_fin[34])
tnr5=feq_fin[34]/(feq_fin[34]+feq_fin[33])
fnr5=feq_fin[35]/(feq_fin[35]+feq_fin[32])
precision5=feq_fin[32]/(feq_fin[32]+feq_fin[33])
recall5=feq_fin[32]/(feq_fin[32]+feq_fin[35])
fscore5=2*precision5*recall5/(precision5+recall5)
fOr5=feq_fin[35]/(feq_fin[35]+feq_fin[34])
fdr5=feq_fin[33]/(feq_fin[32]+feq_fin[33])

ps6=feq_fin[36]/1000
fnz6=feq_fin[37]/1000
fz6=feq_fin[38]/1000
tpr6=feq_fin[39]/(feq_fin[39]+feq_fin[42])
fpr6=feq_fin[40]/(feq_fin[40]+feq_fin[41])
tnr6=feq_fin[41]/(feq_fin[41]+feq_fin[40])
fnr6=feq_fin[42]/(feq_fin[42]+feq_fin[39])
precision6=feq_fin[39]/(feq_fin[39]+feq_fin[40])
recall6=feq_fin[39]/(feq_fin[39]+feq_fin[42])
fscore6=2*precision6*recall6/(precision6+recall6)
fOr6=feq_fin[42]/(feq_fin[42]+feq_fin[41])
fdr6=feq_fin[40]/(feq_fin[39]+feq_fin[40])

ps7=feq_fin[43]/1000
fnz7=feq_fin[44]/1000
fz7=feq_fin[45]/1000
tpr7=feq_fin[46]/(feq_fin[46]+feq_fin[49])
fpr7=feq_fin[47]/(feq_fin[47]+feq_fin[48])
tnr7=feq_fin[48]/(feq_fin[48]+feq_fin[47])
fnr7=feq_fin[49]/(feq_fin[49]+feq_fin[46])
precision7=feq_fin[46]/(feq_fin[46]+feq_fin[47])
recall7=feq_fin[46]/(feq_fin[46]+feq_fin[49])
fscore7=2*precision7*recall7/(precision7+recall7)
fOr7=feq_fin[49]/(feq_fin[49]+feq_fin[48])
fdr7=feq_fin[47]/(feq_fin[46]+feq_fin[47])

ps8=feq_fin[50]/1000
fnz8=feq_fin[51]/1000
fz8=feq_fin[52]/1000
tpr8=feq_fin[53]/(feq_fin[53]+feq_fin[56])
fpr8=feq_fin[54]/(feq_fin[54]+feq_fin[55])
tnr8=feq_fin[55]/(feq_fin[55]+feq_fin[54])
fnr8=feq_fin[56]/(feq_fin[56]+feq_fin[53])
precision8=feq_fin[53]/(feq_fin[53]+feq_fin[54])
recall8=feq_fin[53]/(feq_fin[53]+feq_fin[56])
fscore8=2*precision8*recall8/(precision8+recall8)
fOr8=feq_fin[56]/(feq_fin[56]+feq_fin[55])
fdr8=feq_fin[54]/(feq_fin[53]+feq_fin[54])

ps9=feq_fin[57]/1000
fnz9=feq_fin[58]/1000
fz9=feq_fin[59]/1000
tpr9=feq_fin[60]/(feq_fin[60]+feq_fin[63])
fpr9=feq_fin[61]/(feq_fin[61]+feq_fin[62])
tnr9=feq_fin[62]/(feq_fin[62]+feq_fin[61])
fnr9=feq_fin[63]/(feq_fin[63]+feq_fin[60])
precision9=feq_fin[60]/(feq_fin[60]+feq_fin[61])
recall9=feq_fin[60]/(feq_fin[60]+feq_fin[63])
fscore9=2*precision9*recall9/(precision9+recall9)
fOr9=feq_fin[63]/(feq_fin[63]+feq_fin[62])
fdr9=feq_fin[61]/(feq_fin[60]+feq_fin[61])

bigindexalasso100=cbind(ps1,fnz1,fz1,tpr1,fpr1,tnr1,fnr1,precision1,fscore1,fOr1,fdr1)
bigindexlasso100=cbind(ps2,fnz2,fz2,tpr2,fpr2,tnr2,fnr2,precision2,fscore2,fOr2,fdr2)
bigindexscad100=cbind(ps3,fnz3,fz3,tpr3,fpr3,tnr3,fnr3,precision3,fscore3,fOr3,fdr3)
bigindexalasso200=cbind(ps4,fnz4,fz4,tpr4,fpr4,tnr4,fnr4,precision4,fscore4,fOr4,fdr4)
bigindexlasso200=cbind(ps5,fnz5,fz5,tpr5,fpr5,tnr5,fnr5,precision5,fscore5,fOr5,fdr5)
bigindexscad200=cbind(ps6,fnz6,fz6,tpr6,fpr6,tnr6,fnr6,precision6,fscore6,fOr6,fdr6)
bigindexalasso500=cbind(ps7,fnz7,fz7,tpr7,fpr7,tnr7,fnr7,precision7,fscore7,fOr7,fdr7)
bigindexlasso500=cbind(ps8,fnz8,fz8,tpr8,fpr8,tnr8,fnr8,precision8,fscore8,fOr8,fdr8)
bigindexscad500=cbind(ps9,fnz9,fz9,tpr9,fpr9,tnr9,fnr9,precision9,fscore9,fOr9,fdr9)

save.image('~/Desktop/HDMIDASCDT-38/codes and data/simulation/simulation_choosegamma2.Rdata')

####选择影响门槛的协变量#####
source('~/Desktop/HDMIDASCDT-38/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-38/codes and data/simulation/feqen.R')
####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <- 1000
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)
####simulation_result9####
cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
feq1<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
               .combine='rbind',.errorhandling = "pass")%dopar% {
                 dgps1<-dgp(tt=100,beta1=c(1,0,1,1,rep(0,times=87)),beta2=c(-1,-2,1,-1,rep(0,times=87)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=30,pz=5,z='dependent',e="non-gaussian")
                 dgps2<-dgp(tt=200,beta1=c(1,0,1,1,rep(0,times=87)),beta2=c(-1,-2,1,-1,rep(0,times=87)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=30,pz=5,z='dependent',e="non-gaussian")
                 dgps3<-dgp(tt=500,beta1=c(1,0,1,1,rep(0,times=87)),beta2=c(-1,-2,1,-1,rep(0,times=87)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=30,pz=5,z='dependent',e="non-gaussian")
                 feqen1=feqen(dgps1$y_train,dgps1$x_train,dgps1$slo_train,dgps1$q_train,dgps1$zt_train,dgps1$J,dgps1$L,dgps1$K,dgps1$pz,dgps1$LK,dgps1$JK,dgps1$tt,method='alasso')
                 feqen2=feqen(dgps1$y_train,dgps1$x_train,dgps1$slo_train,dgps1$q_train,dgps1$zt_train,dgps1$J,dgps1$L,dgps1$K,dgps1$pz,dgps1$LK,dgps1$JK,dgps1$tt,method='lasso')
                 feqen3=feqen(dgps1$y_train,dgps1$x_train,dgps1$slo_train,dgps1$q_train,dgps1$zt_train,dgps1$J,dgps1$L,dgps1$K,dgps1$pz,dgps1$LK,dgps1$JK,dgps1$tt,method='scad')
                 feqen4=feqen(dgps2$y_train,dgps2$x_train,dgps2$slo_train,dgps2$q_train,dgps2$zt_train,dgps2$J,dgps2$L,dgps2$K,dgps2$pz,dgps2$LK,dgps2$JK,dgps2$tt,method='alasso')
                 feqen5=feqen(dgps2$y_train,dgps2$x_train,dgps2$slo_train,dgps2$q_train,dgps2$zt_train,dgps2$J,dgps2$L,dgps2$K,dgps2$pz,dgps2$LK,dgps2$JK,dgps2$tt,method='lasso')
                 feqen6=feqen(dgps2$y_train,dgps2$x_train,dgps2$slo_train,dgps2$q_train,dgps2$zt_train,dgps2$J,dgps2$L,dgps2$K,dgps2$pz,dgps2$LK,dgps2$JK,dgps2$tt,method='scad')
                 feqen7=feqen(dgps3$y_train,dgps3$x_train,dgps3$slo_train,dgps3$q_train,dgps3$zt_train,dgps3$J,dgps3$L,dgps3$K,dgps3$pz,dgps3$LK,dgps3$JK,dgps3$tt,method='alasso')
                 feqen8=feqen(dgps3$y_train,dgps3$x_train,dgps3$slo_train,dgps3$q_train,dgps3$zt_train,dgps3$J,dgps3$L,dgps3$K,dgps3$pz,dgps3$LK,dgps3$JK,dgps3$tt,method='lasso')
                 feqen9=feqen(dgps3$y_train,dgps3$x_train,dgps3$slo_train,dgps3$q_train,dgps3$zt_train,dgps3$J,dgps3$L,dgps3$K,dgps3$pz,dgps3$LK,dgps3$JK,dgps3$tt,method='scad')
                 return(c(feqen1$p,feqen1$f1,feqen1$f2,feqen1$tp,feqen1$fp,feqen1$tn,feqen1$fn,feqen2$p,feqen2$f1,feqen2$f2,feqen2$tp,feqen2$fp,feqen2$tn,feqen2$fn,feqen3$p,feqen3$f1,feqen3$f2,feqen3$tp,feqen3$fp,feqen3$tn,feqen3$fn,
                          feqen4$p,feqen4$f1,feqen4$f2,feqen4$tp,feqen4$fp,feqen4$tn,feqen4$fn,feqen5$p,feqen5$f1,feqen5$f2,feqen5$tp,feqen5$fp,feqen5$tn,feqen5$fn,feqen6$p,feqen6$f1,feqen6$f2,feqen6$tp,feqen6$fp,feqen6$tn,feqen6$fn,
                          feqen7$p,feqen7$f1,feqen7$f2,feqen7$tp,feqen7$fp,feqen7$tn,feqen7$fn,feqen8$p,feqen8$f1,feqen8$f2,feqen8$tp,feqen8$fp,feqen8$tn,feqen8$fn,feqen9$p,feqen9$f1,feqen9$f2,feqen9$tp,feqen9$fp,feqen9$tn,feqen9$fn))
               }
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
feq_fin= matrix(0,nrow = 1,ncol =63)
feq_fin= round(colSums(feq1),3)

ps1=feq_fin[1]/1000
fnz1=feq_fin[2]/1000
fz1=feq_fin[3]/1000
tpr1=feq_fin[4]/(feq_fin[4]+feq_fin[7])
fpr1=feq_fin[5]/(feq_fin[5]+feq_fin[6])
tnr1=feq_fin[6]/(feq_fin[6]+feq_fin[5])
fnr1=feq_fin[7]/(feq_fin[7]+feq_fin[4])
precision1=feq_fin[4]/(feq_fin[4]+feq_fin[5])
recall1=feq_fin[4]/(feq_fin[4]+feq_fin[7])
fscore1=2*precision1*recall1/(precision1+recall1)
fOr1=feq_fin[7]/(feq_fin[7]+feq_fin[6])
fdr1=feq_fin[5]/(feq_fin[4]+feq_fin[5])

ps2=feq_fin[8]/1000
fnz2=feq_fin[9]/1000
fz2=feq_fin[10]/1000
tpr2=feq_fin[11]/(feq_fin[11]+feq_fin[14])
fpr2=feq_fin[12]/(feq_fin[12]+feq_fin[13])
tnr2=feq_fin[13]/(feq_fin[13]+feq_fin[12])
fnr2=feq_fin[14]/(feq_fin[14]+feq_fin[11])
precision2=feq_fin[11]/(feq_fin[11]+feq_fin[12])
recall2=feq_fin[11]/(feq_fin[11]+feq_fin[14])
fscore2=2*precision2*recall2/(precision2+recall2)
fOr2=feq_fin[14]/(feq_fin[14]+feq_fin[13])
fdr2=feq_fin[12]/(feq_fin[11]+feq_fin[12])

ps3=feq_fin[15]/1000
fnz3=feq_fin[16]/1000
fz3=feq_fin[17]/1000
tpr3=feq_fin[18]/(feq_fin[18]+feq_fin[21])
fpr3=feq_fin[19]/(feq_fin[19]+feq_fin[20])
tnr3=feq_fin[20]/(feq_fin[20]+feq_fin[19])
fnr3=feq_fin[21]/(feq_fin[21]+feq_fin[18])
precision3=feq_fin[18]/(feq_fin[18]+feq_fin[19])
recall3=feq_fin[18]/(feq_fin[18]+feq_fin[21])
fscore3=2*precision3*recall3/(precision3+recall3)
fOr3=feq_fin[21]/(feq_fin[21]+feq_fin[20])
fdr3=feq_fin[19]/(feq_fin[18]+feq_fin[19])

ps4=feq_fin[22]/1000
fnz4=feq_fin[23]/1000
fz4=feq_fin[24]/1000
tpr4=feq_fin[25]/(feq_fin[25]+feq_fin[28])
fpr4=feq_fin[26]/(feq_fin[26]+feq_fin[27])
tnr4=feq_fin[27]/(feq_fin[27]+feq_fin[26])
fnr4=feq_fin[28]/(feq_fin[28]+feq_fin[25])
precision4=feq_fin[25]/(feq_fin[25]+feq_fin[26])
recall4=feq_fin[25]/(feq_fin[25]+feq_fin[28])
fscore4=2*precision4*recall4/(precision4+recall4)
fOr4=feq_fin[28]/(feq_fin[28]+feq_fin[27])
fdr4=feq_fin[26]/(feq_fin[25]+feq_fin[26])

ps5=feq_fin[29]/1000
fnz5=feq_fin[30]/1000
fz5=feq_fin[31]/1000
tpr5=feq_fin[32]/(feq_fin[32]+feq_fin[35])
fpr5=feq_fin[33]/(feq_fin[33]+feq_fin[34])
tnr5=feq_fin[34]/(feq_fin[34]+feq_fin[33])
fnr5=feq_fin[35]/(feq_fin[35]+feq_fin[32])
precision5=feq_fin[32]/(feq_fin[32]+feq_fin[33])
recall5=feq_fin[32]/(feq_fin[32]+feq_fin[35])
fscore5=2*precision5*recall5/(precision5+recall5)
fOr5=feq_fin[35]/(feq_fin[35]+feq_fin[34])
fdr5=feq_fin[33]/(feq_fin[32]+feq_fin[33])

ps6=feq_fin[36]/1000
fnz6=feq_fin[37]/1000
fz6=feq_fin[38]/1000
tpr6=feq_fin[39]/(feq_fin[39]+feq_fin[42])
fpr6=feq_fin[40]/(feq_fin[40]+feq_fin[41])
tnr6=feq_fin[41]/(feq_fin[41]+feq_fin[40])
fnr6=feq_fin[42]/(feq_fin[42]+feq_fin[39])
precision6=feq_fin[39]/(feq_fin[39]+feq_fin[40])
recall6=feq_fin[39]/(feq_fin[39]+feq_fin[42])
fscore6=2*precision6*recall6/(precision6+recall6)
fOr6=feq_fin[42]/(feq_fin[42]+feq_fin[41])
fdr6=feq_fin[40]/(feq_fin[39]+feq_fin[40])

ps7=feq_fin[43]/1000
fnz7=feq_fin[44]/1000
fz7=feq_fin[45]/1000
tpr7=feq_fin[46]/(feq_fin[46]+feq_fin[49])
fpr7=feq_fin[47]/(feq_fin[47]+feq_fin[48])
tnr7=feq_fin[48]/(feq_fin[48]+feq_fin[47])
fnr7=feq_fin[49]/(feq_fin[49]+feq_fin[46])
precision7=feq_fin[46]/(feq_fin[46]+feq_fin[47])
recall7=feq_fin[46]/(feq_fin[46]+feq_fin[49])
fscore7=2*precision7*recall7/(precision7+recall7)
fOr7=feq_fin[49]/(feq_fin[49]+feq_fin[48])
fdr7=feq_fin[47]/(feq_fin[46]+feq_fin[47])

ps8=feq_fin[50]/1000
fnz8=feq_fin[51]/1000
fz8=feq_fin[52]/1000
tpr8=feq_fin[53]/(feq_fin[53]+feq_fin[56])
fpr8=feq_fin[54]/(feq_fin[54]+feq_fin[55])
tnr8=feq_fin[55]/(feq_fin[55]+feq_fin[54])
fnr8=feq_fin[56]/(feq_fin[56]+feq_fin[53])
precision8=feq_fin[53]/(feq_fin[53]+feq_fin[54])
recall8=feq_fin[53]/(feq_fin[53]+feq_fin[56])
fscore8=2*precision8*recall8/(precision8+recall8)
fOr8=feq_fin[56]/(feq_fin[56]+feq_fin[55])
fdr8=feq_fin[54]/(feq_fin[53]+feq_fin[54])

ps9=feq_fin[57]/1000
fnz9=feq_fin[58]/1000
fz9=feq_fin[59]/1000
tpr9=feq_fin[60]/(feq_fin[60]+feq_fin[63])
fpr9=feq_fin[61]/(feq_fin[61]+feq_fin[62])
tnr9=feq_fin[62]/(feq_fin[62]+feq_fin[61])
fnr9=feq_fin[63]/(feq_fin[63]+feq_fin[60])
precision9=feq_fin[60]/(feq_fin[60]+feq_fin[61])
recall9=feq_fin[60]/(feq_fin[60]+feq_fin[63])
fscore9=2*precision9*recall9/(precision9+recall9)
fOr9=feq_fin[63]/(feq_fin[63]+feq_fin[62])
fdr9=feq_fin[61]/(feq_fin[60]+feq_fin[61])

debigindexalasso100=cbind(ps1,fnz1,fz1,tpr1,fpr1,tnr1,fnr1,precision1,fscore1,fOr1,fdr1)
debigindexlasso100=cbind(ps2,fnz2,fz2,tpr2,fpr2,tnr2,fnr2,precision2,fscore2,fOr2,fdr2)
debigindexscad100=cbind(ps3,fnz3,fz3,tpr3,fpr3,tnr3,fnr3,precision3,fscore3,fOr3,fdr3)
debigindexalasso200=cbind(ps4,fnz4,fz4,tpr4,fpr4,tnr4,fnr4,precision4,fscore4,fOr4,fdr4)
debigindexlasso200=cbind(ps5,fnz5,fz5,tpr5,fpr5,tnr5,fnr5,precision5,fscore5,fOr5,fdr5)
debigindexscad200=cbind(ps6,fnz6,fz6,tpr6,fpr6,tnr6,fnr6,precision6,fscore6,fOr6,fdr6)
debigrindexalasso500=cbind(ps7,fnz7,fz7,tpr7,fpr7,tnr7,fnr7,precision7,fscore7,fOr7,fdr7)
debigindexlasso500=cbind(ps8,fnz8,fz8,tpr8,fpr8,tnr8,fnr8,precision8,fscore8,fOr8,fdr8)
debigindexscad500=cbind(ps9,fnz9,fz9,tpr9,fpr9,tnr9,fnr9,precision9,fscore9,fOr9,fdr9)

save.image('~/Desktop/HDMIDASCDT-38/codes and data/simulation/simulation_choosegamma2.Rdata')