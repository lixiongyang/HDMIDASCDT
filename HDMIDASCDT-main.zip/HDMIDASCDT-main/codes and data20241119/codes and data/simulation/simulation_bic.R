rm(list=ls())
####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result1<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=100,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='independent',e="gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算

lie=ncol(result1)
rs1ingu100= matrix(0,nrow = 2,ncol =lie)
rs1ingu100[1,] = round(colMeans(result1),3)
for (i in 1:lie) {
  rs1ingu100[2,i] = round(sd(result1[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-38/codes and data/simulation/simulation_estimation3.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result2<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=200,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='independent',e="gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result2)
rs2ingu200= matrix(0,nrow = 2,ncol =lie)
rs2ingu200[1,] = round(colMeans(result2),3)
for (i in 1:lie) {
  rs2ingu200[2,i] = round(sd(result2[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation1.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result3<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=500,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='independent',e="gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result3)
rs3ingu500= matrix(0,nrow = 2,ncol =lie)
rs3ingu500[1,] = round(colMeans(result3),3)
for (i in 1:lie) {
  rs3ingu500[2,i] = round(sd(result3[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation1.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result4<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=1000,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='independent',e="gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result4)
rs4ingu1000= matrix(0,nrow = 2,ncol =lie)
rs4ingu1000[1,] = round(colMeans(result4),3)
for (i in 1:lie) {
  rs4ingu1000[2,i] = round(sd(result4[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation1.Rdata')

###第一组对比实验###
####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result5<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=100,beta1=c(1,0,1,1,rep(0,times=15)),beta2=c(-1,-2,1,-1,rep(0,times=15)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=6,J=12,K=3,pz=5,z='independent',e="gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result5)
rs5ingu100= matrix(0,nrow = 2,ncol =lie)
rs5ingu100[1,] = round(colMeans(result5),3)
for (i in 1:lie) {
  rs5ingu100[2,i] = round(sd(result5[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation1.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result6<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=200,beta1=c(1,0,1,1,rep(0,times=15)),beta2=c(-1,-2,1,-1,rep(0,times=15)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=6,J=12,K=3,pz=5,z='independent',e="gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result6)
rs6ingu200= matrix(0,nrow = 2,ncol =lie)
rs6ingu200[1,] = round(colMeans(result6),3)
for (i in 1:lie) {
  rs6ingu200[2,i] = round(sd(result6[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation1.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result7<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=500,beta1=c(1,0,1,1,rep(0,times=15)),beta2=c(-1,-2,1,-1,rep(0,times=15)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=6,J=12,K=3,pz=5,z='independent',e="gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result7)
rs7ingu500= matrix(0,nrow = 2,ncol =lie)
rs7ingu500[1,] = round(colMeans(result7),3)
for (i in 1:lie) {
  rs7ingu500[2,i] = round(sd(result7[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation1.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result8<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=100,beta1=c(1,0,1,1,rep(0,times=87)),beta2=c(-1,-2,1,-1,rep(0,times=87)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=30,pz=5,z='independent',e="gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result8)
rs8ingu100= matrix(0,nrow = 2,ncol =lie)
rs8ingu100[1,] = round(colMeans(result8),3)
for (i in 1:lie) {
  rs8ingu100[2,i] = round(sd(result8[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation1.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result9<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=200,beta1=c(1,0,1,1,rep(0,times=87)),beta2=c(-1,-2,1,-1,rep(0,times=87)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=30,pz=5,z='independent',e="gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result9)
rs9ingu200= matrix(0,nrow = 2,ncol =lie)
rs9ingu200[1,] = round(colMeans(result9),3)
for (i in 1:lie) {
  rs9ingu200[2,i] = round(sd(result9[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation1.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result10<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                   .combine='rbind',.errorhandling = "pass") %dopar% {
                     d1 =dgp(tt=500,beta1=c(1,0,1,1,rep(0,times=87)),beta2=c(-1,-2,1,-1,rep(0,times=87)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=30,pz=5,z='independent',e="gaussian")
                     rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                     sum1=sum(rt_choose1$feq1)
                     test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                     sum2=sum(test1$feq2)
                     sum3=sum(test1$feq3)
                     pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                     test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                     sum4=sum(test1_noth$feq2)
                     pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                     return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                     ))
                   } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result10)
rs10ingu500= matrix(0,nrow = 2,ncol =lie)
rs10ingu500[1,] = round(colMeans(result10),3)
for (i in 1:lie) {
  rs10ingu500[2,i] = round(sd(result10[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation1.Rdata')


rm(list=ls())
####第二组对比实验###
####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result1<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=100,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='dependent',e="non-gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算

lie=ncol(result1)
rs1denon100= matrix(0,nrow = 2,ncol =lie)
rs1denon100[1,] = round(colMeans(result1),3)
for (i in 1:lie) {
  rs1denon100[2,i] = round(sd(result1[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation2.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')


cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result2<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=200,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='dependent',e="non-gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result2)
rs2denon200= matrix(0,nrow = 2,ncol =lie)
rs2denon200[1,] = round(colMeans(result2),3)
for (i in 1:lie) {
  rs2denon200[2,i] = round(sd(result2[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation2.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result3<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=500,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=1,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='dependent',e="non-gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result3)
rs3denon500= matrix(0,nrow = 2,ncol =lie)
rs3denon500[1,] = round(colMeans(result3),3)
for (i in 1:lie) {
  rs3denon500[2,i] = round(sd(result3[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation2.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result4<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=100,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=0,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='independent',e="gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1_noth$perf,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result4)
rs4ingu100= matrix(0,nrow = 2,ncol =lie)
rs4ingu100[1,] = round(colMeans(result4),3)
for (i in 1:lie) {
  rs4ingu100[2,i] = round(sd(result4[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation2.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result5<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=200,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=0,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='independent',e="gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1_noth$perf,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result5)
rs5ingu200= matrix(0,nrow = 2,ncol =lie)
rs5ingu200[1,] = round(colMeans(result5),3)
for (i in 1:lie) {
  rs5ingu200[2,i] = round(sd(result5[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation2.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('~/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result6<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=500,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=0,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='independent',e="gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1_noth$perf,test1_noth$perf,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result6)
rs6ingu500= matrix(0,nrow = 2,ncol =lie)
rs6ingu500[1,] = round(colMeans(result6),3)
for (i in 1:lie) {
  rs6ingu500[2,i] = round(sd(result6[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation2.Rdata')

rm(list=ls())
####第二组对比实验###
####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('C:/Users/Administrator.DESKTOP-CGN84Q5/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('C:/Users/Administrator.DESKTOP-CGN84Q5/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result1<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=100,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=0,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='dependent',e="non-gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1_noth$perf,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result1)
rs1denon100= matrix(0,nrow = 2,ncol =lie)
rs1denon100[1,] = round(colMeans(result1),3)
for (i in 1:lie) {
  rs1denon100[2,i] = round(sd(result1[,i]),3)
}

save.image('C:/Users/Administrator.DESKTOP-CGN84Q5/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation3.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('C:/Users/Administrator.DESKTOP-CGN84Q5/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('C:/Users/Administrator.DESKTOP-CGN84Q5/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result2<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=200,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=0,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='dependent',e="non-gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1_noth$perf,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result2)
rs2denon200= matrix(0,nrow = 2,ncol =lie)
rs2denon200[1,] = round(colMeans(result2),3)
for (i in 1:lie) {
  rs2denon200[2,i] = round(sd(result2[,i]),3)
}

save.image('C:/Users/Administrator.DESKTOP-CGN84Q5/Desktop/HDMIDASCDT-31/codes and data/simulation/simulation_estimation3.Rdata')

####settings####
library(doSNOW)
library(foreach)
library(iterators)
library(parallel)
library(doParallel)
xc= detectCores()#CPU可使用的核数
Btimes <-500
pb <- txtProgressBar(min=1, max=Btimes, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

source('C:/Users/Administrator.DESKTOP-CGN84Q5/Desktop/HDMIDASCDT-31/codes and data/simulation/dgp.R')
source('C:/Users/Administrator.DESKTOP-CGN84Q5/Desktop/HDMIDASCDT-31/codes and data/simulation/function_bic.R')

cl <- makeSOCKcluster(xc)#设置参与并行核数

#clusterEvalQ(cl, .libPaths("~/R/x86_64-pc-linux-gnu-library/4.2/")) 

registerDoSNOW(cl)
time1 <- Sys.time()
result3<- foreach(i=1:Btimes, .packages = c('ncvreg','msgps','glmnet','pracma','midasml',"BayesianTools"), .options.snow=opts,
                  .combine='rbind',.errorhandling = "pass") %dopar% {
                    d1 =dgp(tt=500,beta1=c(1,0,1,1,rep(0,times=6)),beta2=c(-1,-2,1,-1,rep(0,times=6)),a=0,gamma_real=c(0.1,0.5,0.6,rep(0,times=3)),L=3,J=12,K=3,pz=5,z='dependent',e="non-gaussian")
                    rt_choose1=rt_choose(d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$J,d1$L,d1$K,d1$pz,d1$LK,d1$JK,d1$tt)
                    sum1=sum(rt_choose1$feq1)
                    test1 =tm_mcmc_est(d1$beta,d1$gamma_real,d1$y1_train,d1$y_train,d1$x_train,d1$slo_train,d1$q_train,d1$zt_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,rt_choose1$corr,d1$tt,d1$pz)
                    sum2=sum(test1$feq2)
                    sum3=sum(test1$feq3)
                    pre1=pre(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$zt_test,d1$J,d1$L,d1$K,test1$gahat,test1$beita_hat,test1$beita_hat1,d1$LK,d1$JK,rt_choose1$corr,d1$pz)
                    test1_noth<-tm_mcmc_est_noth(d1$beta,d1$y1_train,d1$y_train,d1$slo_train,d1$x_train,d1$q_train,d1$L,d1$J,d1$K,d1$LK,d1$JK,d1$tt)
                    sum4=sum(test1_noth$feq2)
                    pre1_noth<-pre_noth(d1$y1_test,d1$y_test,d1$x_test,d1$q_test,d1$slo_test,d1$J,d1$L,d1$K,test1_noth$beita_hat,d1$LK,d1$JK)
                    return(c(test1$sse_es,test1$sse_es1,test1$sse_es2,test1$sse_es3,test1_noth$sse_es,test1_noth$sse_es1,pre1$rmse,pre1$rmse1,pre1$rmse2,pre1$rmse3,pre1_noth$rmse,pre1_noth$rmse1,test1$gal1,test1$gal2,test1$betal1,test1$betal2,test1$betal3,test1$betal4,test1_noth$betal1,test1_noth$betal2,test1$perf1,test1$perf2,test1_noth$perf,test1$c,test1$wx1,test1$wx2,test1$lx1,test1$lx2,test1_noth$wx,test1_noth$lx,test1$gahat1,test1$beita_hat,test1$beita_hat1,sum1,sum2,sum3,sum4,test1_noth$beita_hat
                    ))
                  } 
Sys.time() - time1
close(pb)
stopCluster(cl)#关闭并行运算
lie=ncol(result3)
rs3denon500= matrix(0,nrow = 2,ncol =lie)
rs3denon500[1,] = round(colMeans(result3),3)
for (i in 1:lie) {
  rs3denon500[2,i] = round(sd(result3[,i]),3)
}

save.image('~/Desktop/HDMIDASCDT-63/codes and data/simulation/simulation_estimation4.Rdata')

