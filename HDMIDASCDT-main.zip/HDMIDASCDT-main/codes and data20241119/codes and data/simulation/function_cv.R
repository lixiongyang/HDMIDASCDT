library("glmnet")
library("midasml")
library('BayesianTools')
library("pracma")
library("msgps")
library("ncvreg")


getmin <- function(lambda, cvm, cvsd) {
  cvmin <- min(cvm)
  idmin <- cvm <= cvmin
  lambda.min <- max(lambda[idmin])
  idmin <- match(lambda.min, lambda)
  semin <- (cvm + cvsd)[idmin]
  idmin <- cvm <= semin
  lambda.1se <- max(lambda[idmin])
  list(lambda.min = lambda.min, lambda.1se = lambda.1se,cvmin=cvmin)
}

cv.sglpath <- function(outlist, lambda, x, y, nfolds,foldid) {
  typenames <- "Single outcome sg-LASSO"
  y <- as.double(y)
  predmat <- matrix(NA, length(y), length(lambda))
  nlams <- double(nfolds)
  for (i in seq(nfolds)) {
    whichfold <- which(foldid == i)
    fitobj <- outlist[[i]]
    preds <- predict(fitobj, x[whichfold, , drop = FALSE])
    nlami <- length(outlist[[i]]$lambda)
    predmat[whichfold, seq(nlami)] <- preds
    nlams[i] <- nlami
  }
  cvraw <- (y-predmat)^2
  N <- length(y) - apply(is.na(predmat), 2, sum)
  cvm <- apply(cvraw, 2, mean, na.rm = TRUE)
  cvsd <- sqrt(apply(scale(cvraw, cvm, FALSE)^2, 2, mean, na.rm = TRUE)/(N - 1))
  list(cvm = cvm, cvsd = cvsd, name = typenames)
} 


cv.sglfit <- function(x, y, gindex,pf, nfolds, parallel,lambda.factor) {
  N <- nrow(x)
  p <- ncol(x)
  y <- drop(y)

  allgamma=seq(0,1,0.1)
  length_gamma=length(allgamma)
  mse=rep(0,times=length_gamma)
  finallist <- vector("list", length = length_gamma)
  
  for(i in 1:length_gamma){

  gamma=allgamma[i]
  sglfit.object <- sglfit(x, y, gamma = gamma,pf=pf, gindex = gindex,lambda.factor=lambda.factor)
  lambda <- sglfit.object$lambda
  
  foldid <- sort(rep(1:nfolds, times = ceiling(N/nfolds))[1:N])

  if (nfolds < 3) 
    stop("nfolds must be at least 3; nfolds=10 recommended")
  
  outlist <- vector("list", length = nfolds)
  if (parallel){
    outlist <- foreach(j = seq(nfolds), .packages = c("midasml")) %dopar%{
      whichfoldnot <- which(!foldid == j)
      y_sub <- y[whichfoldnot]
      sglfit(x = x[whichfoldnot, , drop = FALSE], y = y_sub, 
             lambda = lambda, gamma = gamma,pf=pf, gindex = gindex,lambda.factor=lambda.factor )
    }
  } else {
    for (k in seq(nfolds)) {
      whichfoldnot <- which(!foldid == k)
      y_sub <- y[whichfoldnot]
      outlist[[k]] <- sglfit(x = x[whichfoldnot, , drop = FALSE], 
                             y = y_sub, lambda = lambda, gamma = gamma,pf=pf, gindex = gindex,lambda.factor=lambda.factor)
    }
  }
  cvstuff <- cv.sglpath(outlist, lambda = lambda, x = x, y = y, nfolds=nfolds,foldid=foldid)
  cvm <- cvstuff$cvm
  cvsd <- cvstuff$cvsd
  cvname <- cvstuff$name
  lamin <- getmin(lambda, cvm, cvsd)
  idxmin <- which(lamin$lambda.min == lambda)
  idx1se <- which(lamin$lambda.1se == lambda)
  cv.fit <- list(lam.min = list(b0 = sglfit.object$b0[idxmin], beta = sglfit.object$beta[,idxmin],cvmin=lamin$cvmin), 
                 lam.1se = list(b0 = sglfit.object$b0[idx1se], beta = sglfit.object$beta[,idx1se]))
  
  obj <- list(lambda = lambda, gamma = gamma, cvm = cvm, cvsd = cvsd, cvupper = cvm + 
                cvsd, cvlower = cvm - cvsd, name = cvname, lamin = lamin, 
              sgl.fit = sglfit.object, cv.fit = cv.fit)

  finallist[[i]]=obj
  mse[i]=lamin$cvmin
  }
  index=max(which(mse==min(mse)))
  object.final=finallist[[index]]
  beita=object.final$cv.fit$lam.min$beta
  lambdamin=object.final$lamin$lambda.min
  return(list(beita=beita,lambdamin=lambdamin))
} 


MAP2 <- function (bayesianOutput, ...) 
{
  samples = BayesianTools::getSample(bayesianOutput, parametersOnly = F, 
                                     ...)
  if ("mcmcSamplerList" %in% class(bayesianOutput)) 
    nPars <- bayesianOutput[[1]]$setup$numPars
  else nPars = bayesianOutput$setup$numPars
  best = which(samples[, nPars + 1] == max(samples[, nPars + 1]))
  cdb = length(best)
  if(cdb == 1){
    parametersMAP = samples[best, 1:nPars]
    valuesMAP = samples[best,(nPars + 1):(nPars + 3)]
  }else{
    samples2 = colMeans(samples[best,])
    parametersMAP = samples2[1:nPars]
    valuesMAP = samples2[(nPars + 1):(nPars + 3)]
  }
  
  return(list(parametersMAP = parametersMAP, valuesMAP = valuesMAP))
}


###选择影响门槛值的协变量###
rt_choose<-function(y_train,x_train,slo_train,q_train,zt_train,J,L,K,pz,LK,JK,tt){
  # y_train=d1$y_train
  # x_train=d1$x_train
  # slo_train=d1$slo_train
  # q_train=d1$q_train
  # zt_train=d1$zt_train
  # J=d1$J
  # L=d1$L
  # K=d1$K
  # pz=d1$pz
  # tt=d1$tt
  LK=L*K
  JK=J*K
  A=x_train
  x20=matrix(nrow=0,ncol=((LK)*(pz)))
  for(i in 1:(tt)){
    xizj=kronecker(A[i,],zt_train[i,])
    x20=rbind(x20,xizj)
  }
  x10=matrix(nrow=0,ncol=(LK))
  for(i in 1:(tt)){
    xiq=A[i,]*q_train[i]
    x10=rbind(x10,xiq)
  }
  x20=as.matrix(x20)
  x10=as.matrix(x10)
  B=cbind(zt_train,A,q_train,x10,x20)
  B=as.matrix(B)
  dim=ncol(B)
  
  alasso_fit=msgps(B,y_train,penalty="alasso",alpha=0,gamma=1,DFtype="MODIFIED",intercept=TRUE,stand.coef=TRUE)
  gamma_est=alasso_fit$dfbic_result$coef[2:(pz+1)]
  
  feq1=matrix(0,1,pz)
  for(i in 1:pz){
    if(gamma_est[i]!=0){
      feq1[i]=1
    }
    else{
      feq1[i]=0
    }
  }
  feq1=as.numeric(feq1)
  corr=matrix(nrow=1,ncol=0)
  for(i in 1:pz){
    if(gamma_est[i]!=0){
      corr=cbind(corr,i)
    }
    else{
      corr=corr
    }
  }
  corr=as.numeric(corr)
  
  return(list(feq1=feq1,corr=corr))
}

####MODEL####
tm_mcmc_est<-function(beta,gamma_real,y1_train,y_train,x_train,slo_train,q_train,zt_train,L,J,K,LK,JK,corr,tt,pz){
  # beta=d1$beta
  # gamma_real=d1$gamma_real
  # y_train=d1$y_train
  # x_train=d1$x_train
  # slo_train=d1$slo_train
  # q_train=d1$q_train
  # zt_train=d1$zt_train
  # L=d1$L
  # J=d1$J
  # K=d1$K
  # LK=d1$LK
  # JK=d1$JK
  # corr=rt_choose1$corr
  # tt=d1$tt
  # pz=d1$pz
  pos.part <- function(q, r){ifelse(q>r,1,0)}
  neg.part <- function(q, r){ifelse(q<=r,1,0)}
 
  sse_ga<-function(ga){
    if(length(corr)==0){
      gammat=rep(ga,(tt))
    }else{
      zt_tel=matrix(nrow=(tt),ncol=0)
      for(i in 1:length(corr)){
        num=corr[i]
        zt_tel=cbind(zt_tel,zt_train[,num])
      }
      zt1=rep(1,times=(tt))
      zt_tel=cbind(zt1,zt_tel)
      gammat <-zt_tel%*%ga
    }
    gammat=as.numeric(gammat)
    
    slo1<-slo_train#*pos.part(q_train,gammat)
    slo2<-slo_train*neg.part(q_train,gammat)
    
    xk1=x_train#*pos.part(q_train,gammat)
    xk2=x_train*neg.part(q_train,gammat)
    
    
    X_sse<-cbind(slo1,xk1,slo2,xk2)
    
    gindex =sort(c(1,rep(2:(K+1),times=L),(K+2),rep((K+3):(2*K+2),times=L)))
    pf = c(0,rep(1,times=(LK)),0,rep(1,times=(LK)))
    
    beita<-cv.sglfit(x=X_sse,y=y_train,gindex = gindex,pf=pf,nfolds=10,parallel=FALSE,lambda.factor=0.01)$beita
    sse_es=sum((y_train - as.numeric(X_sse%*%beita))^2)
    return(sse_es)
  }
  
  r1 <- quantile(q_train, probs = 0.15)
  r2 <- quantile(q_train, probs = 0.85)
  
  
  ####mcmc####
  ms=3000
  bur=3000
  miq = mean(q_train)
  pdffun_new <- function(ga) {
    pn = -sse_ga(ga)
    return(pn)
  }
  
  jj = matrix(1,nrow =(tt),ncol = 1)
  jj = cbind(jj,zt_train)
  nhe1 = qr.resid(qr(jj),q_train)
  lc = max(abs(nhe1)) + 1
  left_c = (nhe1 - lc)
  right_c = (nhe1 + lc)
  left_c = min(left_c)
  right_c= max(right_c)
  
  # left_c =0
  # right_c=7
  
  priors<-createUniformPrior(lower=c(r1,rep(left_c,times=length(corr))),upper=c(r2,rep(right_c,times=length(corr))))
  bayesianSetup<-createBayesianSetup(pdffun_new,prior=priors)
  sett_trainings=list(iterations=(ms+bur),burnin=bur)
  gapost <- runMCMC(bayesianSetup=bayesianSetup,sampler="DREAMzs",settings=sett_trainings)
  gahat<-MAP2(gapost)$parametersMAP
  #gelmanDiagnostics(gapost,plot = T)
  
  if(length(corr)==0){
    rt_es=rep(gahat,(tt))
  }else{
    zt_fin=matrix(nrow=(tt),ncol=0)
    for(i in 1:length(corr)){
      num=corr[i]
      zt_fin=cbind(zt_fin,zt_train[,num])
    }
    zt1=rep(1,times=(tt))
    zt_fin=cbind(zt1,zt_fin)
    rt_es =zt_fin%*%gahat
  }
  rt_es=as.numeric(rt_es)
  
  slo1<-slo_train#*pos.part(q_train,rt_es)
  slo2<-slo_train*neg.part(q_train,rt_es)
  
  xk1=x_train#*pos.part(q_train,rt_es)
  xk2=x_train*neg.part(q_train,rt_es)
  

  X<-cbind(slo1,xk1,slo2,xk2)
  gindex =sort(c(1,rep(2:(K+1),times=L),(K+2),rep((K+3):(2*K+2),times=L)))
  pf = c(0,rep(1,times=(LK)),0,rep(1,times=(LK)))
  
  cvsglfit<-cv.sglfit(x=X,y=y_train,gindex = gindex,pf=pf,nfolds=10,parallel=FALSE,lambda.factor=0.01)
   
  beita_hat=cvsglfit$beita
  beita_hat1=beita_hat
  lamin=cvsglfit$lambdamin
  
  c0=seq(0,10,by=0.1)
  grid_c = length(c0)
  mse_c = rep(NA,grid_c)
  bic_c = rep(NA,grid_c)
  ##网格搜索###
  for (i in 1:grid_c){
    beita_C=beita_hat1
    beita_C[abs(beita_C) < 2*c0[i]*lamin]=0
    mse_c[i]= sum((y_train - X%*%beita_C )^2) /tt
    bic_c[i] = mse_c[i] + (sum(beita_C!=0)) * log(tt)/tt
  }
  
  index = which(bic_c==min(bic_c),arr.ind=T)
  c=c0[index]
  if (length(c)>1)
    c<- max(c)
  beita_hat1[abs(beita_hat1) < 2*c*lamin]=0
  
  sse_es <- sqrt(sum((y1_train - as.numeric(X%*%beita_hat))^2)/tt)
  sse_es1 <-sqrt(sum((y_train - as.numeric(X%*%beita_hat))^2)/tt)
  sse_es2 <- sqrt(sum((y1_train - as.numeric(X%*%beita_hat1))^2)/tt)
  sse_es3 <- sqrt(sum((y_train - as.numeric(X%*%beita_hat1))^2)/tt)
  
  sy=matrix(0,1,(2*LK+2))
  for(i in 1:(2*LK+2)){
    if(beta[i]!=0){
      sy[i]=1
    }
    else{
      sy[i]=0
    }
  }
  sy=as.numeric(sy)
  
  feq2=matrix(0,1,(2*LK+2))
  for(i in 1:(2*LK+2)){
    if(beita_hat[i]!=0){
      feq2[i]=1
    }
    else{
      feq2[i]=0
    }
  }
  feq2=as.numeric(feq2)
  
  feq3=matrix(0,1,(2*LK+2))
  for(i in 1:(2*LK+2)){
    if(beita_hat1[i]!=0){
      feq3[i]=1
    }
    else{
      feq3[i]=0
    }
  }
  feq3=as.numeric(feq3)
  
  bz1=sy-feq2
  bz2=sy-feq3
  wx1=sum(bz1==-1)
  wx2=sum(bz2==-1)
  lx1=sum(bz1==1)
  lx2=sum(bz2==1)
  perf1=0
  if(sum(bz1==0)==(2*LK+2)){
    perf1=1
  }
  perf2=0
  if(sum(bz2==0)==(2*LK+2)){
    perf2=1
  }
  corr1=as.numeric(cbind(1,t(corr+1)))
  gahat1=matrix(0,1,(pz+1))
  for(i in 1:length(corr1)){
    num=corr1[i]
    gahat1[num]=gahat[i]
  }
  gahat1=as.numeric(gahat1)
  gal1=sum(abs(gahat1-gamma_real))
  gal2=max(abs(gahat1-gamma_real))
  betal1=sum(abs(beita_hat-beta))
  betal2=max(abs(beita_hat-beta))
  betal3=sum(abs(beita_hat1-beta))
  betal4=max(abs(beita_hat1-beta))
  return(list(perf1=perf1,perf2=perf2,c=c,wx1=wx1,wx2=wx2,lx1=lx1,lx2=lx2,feq2=feq2,feq3=feq3,gahat=gahat,gahat1=gahat1,beita_hat=beita_hat,beita_hat1=beita_hat1,gal1=gal1,gal2=gal2,betal1=betal1,betal2=betal2,betal3=betal3,betal4=betal4,sse_es=sse_es,sse_es1=sse_es1,sse_es2=sse_es2,sse_es3=sse_es3))
  
}


###预测###
pre<-function(y1_test,y_test,x_test,q_test,slo_test,zt_test,J,L,K,gahat,beita_hat,beita_hat1,LK,JK,corr,pz){
  # y_test=d1$y_test
  # x_test=d1$x_test
  # q_test=d1$q_test
  # y1_test=d1$y1_test
  # slo_test=d1$slo_test
  # zt_test=d1$zt_test
  # J=d1$J
  # L=d1$L
  # K=d1$K
  # gahat=test1$gahat
  # beita_hat=test1$beita_hat
  # beita_hat1=test1$beita_hat1
  # LK=d1$LK
  # JK=d1$JK
  # corr=rt_choose1$corr
  # pz=d1$pz
  pos.part <- function(q, r){ifelse(q>r,1,0)}
  neg.part <- function(q, r){ifelse(q<=r,1,0)}
  
  if(length(corr)==0){
    gammat=rep(gahat,(100))
  }else{
    zt_tel=matrix(nrow=100,ncol=0)
    for(i in 1:length(corr)){
      num=corr[i]
      zt_tel=cbind(zt_tel,zt_test[,num])
    }
    zt1=rep(1,times=(100))
    zt_tel=cbind(zt1,zt_tel)
    gammat <-zt_tel%*%gahat
  }
  gammat=as.numeric(gammat)
  
  slo1<-slo_test#*pos.part(q_test,gammat)
  slo2<-slo_test*neg.part(q_test,gammat)
  
  xk1=x_test#*pos.part(q_test,gammat)
  xk2=x_test*neg.part(q_test,gammat)
  
  X_test<-cbind(slo1,xk1,slo2,xk2)
  
  rmse=sqrt(sum((y1_test-as.numeric(X_test%*%beita_hat))^2)/100)
  rmse1=sqrt(sum((y_test-as.numeric(X_test%*%beita_hat))^2)/100)
  rmse2=sqrt(sum((y1_test-as.numeric(X_test%*%beita_hat1))^2)/100)
  rmse3=sqrt(sum((y_test-as.numeric(X_test%*%beita_hat1))^2)/100)

  return(list(rmse=rmse,rmse1=rmse1,rmse2=rmse2,rmse3=rmse3))
}


####MODEL####
tm_mcmc_est_noth<-function(beta,y1_train,y_train,x_train,slo_train,q_train,L,J,K,LK,JK,tt){
  # beta=d1$beta
  # y_train=d1$y_train
  # x_train=d1$x_train
  # slo_train=d1$slo_train
  # q_train=d1$q_train
  # L=d1$L
  # J=d1$J
  # K=d1$K
  # LK=d1$LK
  # JK=d1$JK
  # tt=d1$tt
  X<-cbind(slo_train,x_train)
  gindex =sort(c(1,rep(2:(K+1),times=L)))
  pf=c(0,rep(1,times=(LK)))
  
  beita_hat<-cv.sglfit(x=X,y=y_train,gindex = gindex,pf=pf,nfolds=10,parallel=FALSE,lambda.factor=0.01)$beita
  sse_es=sqrt(sum((y1_train - as.numeric(X%*%beita_hat))^2)/tt)
  sse_es1=sqrt(sum((y_train - as.numeric(X%*%beita_hat))^2)/tt)
  beita_hat1=c(beita_hat,rep(0,1,length(beita_hat)))
  
  sy=matrix(0,1,(2*LK+2))
  for(i in 1:(2*LK+2)){
    if(beta[i]!=0){
      sy[i]=1
    }
    else{
      sy[i]=0
    }
  }
  sy=as.numeric(sy)
  
  feq2=matrix(0,1,(2*LK+2))
  for(i in 1:(2*LK+2)){
    if(beita_hat1[i]!=0){
      feq2[i]=1
    }
    else{
      feq2[i]=0
    }
  }
  feq2=as.numeric(feq2)
  bz=sy-feq2
  wx=sum(bz==-1)
  lx=sum(bz==1)
  perf=0
  if(sum(bz==0)==(2*LK+2)){
    perf=1
  }
  betal1=sum(abs(beita_hat-beta))
  betal2=max(abs(beita_hat-beta))
  
  return(list(perf=perf,wx=wx,lx=lx,feq2=feq2,beita_hat=beita_hat,beita_hat1=beita_hat1,betal1=betal1,betal2=betal2,sse_es=sse_es,sse_es1=sse_es1))
  
}


###预测####
pre_noth<-function(y1_test,y_test,x_test,q_test,slo_test,J,L,K,beita_hat,LK,JK){
  X_test<-cbind(slo_test,x_test)
  rmse=sqrt(sum((y1_test-as.numeric(X_test%*%beita_hat))^2)/100)
  rmse1=sqrt(sum((y_test-as.numeric(X_test%*%beita_hat))^2)/100)

  return(list(rmse=rmse,rmse1=rmse1))
}




